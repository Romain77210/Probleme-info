﻿using GrapheApp;
using Xunit;

namespace GrapheApp.Tests
{
    public class StationTests
    {
        [Fact]
        public void Station_Constructeur_AssigneLesValeursCorrectement()
        {
            // Arrange
            string nom = "Gare";
            double lon = 2.35;
            double lat = 48.85;

            // Act
            var station = new Station(nom, lon, lat);

            // Assert
            Assert.Equal(nom, station.Nom);
            Assert.Equal(lon, station.Longitude);
            Assert.Equal(lat, station.Latitude);
        }

        [Fact]
        public void StationTemp_Constructeur_AssigneLesValeursCorrectement()
        {
            // Arrange
            string nom = "GareTemp";
            double lon = 1.23;
            double lat = 4.56;

            // Act
            var temp = new StationTemp(nom, lon, lat);

            // Assert
            Assert.Equal(nom, temp.Nom);
            Assert.Equal(lon, temp.Longitude);
            Assert.Equal(lat, temp.Latitude);
        }
    }
}
