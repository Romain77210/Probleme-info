using System.Collections.Generic;
using GrapheApp;
using Xunit;
using static System.Collections.Specialized.BitVector32;

namespace GrapheApp.Tests
{
    public class TestLien
    {
        [Fact]
        public void Contient_Station1EtStation2_RetourneVrai()
        {
            // Arrange
            var s1 = new Station("A", 0, 0);
            var s2 = new Station("B", 1, 1);
            var lien = new Lien(s1, s2, 5);

            // Act & Assert
            Assert.True(lien.Contient(s1));
            Assert.True(lien.Contient(s2));
            Assert.True(lien.Contient(s1, s2));
            Assert.True(lien.Contient(s2, s1));
        }

        [Fact]
        public void Autre_StationRetourneOpposee()
        {
            // Arrange
            var s1 = new Station("A", 0, 0);
            var s2 = new Station("B", 1, 1);
            var lien = new Lien(s1, s2, 5);

            // Act
            var autre = lien.Autre(s1);

            // Assert
            Assert.Equal(s2, autre);
        }
    }
}
