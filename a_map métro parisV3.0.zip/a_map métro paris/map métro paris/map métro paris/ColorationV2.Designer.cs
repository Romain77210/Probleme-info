﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace GrapheApp
{
    public partial class ColorationV2 : Form
    {
        /// <summary>
        /// Conteneur pour les composants utilisés par le formulaire.
        /// </summary>
        private System.ComponentModel.IContainer composant = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (composant != null))
            {
                composant.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Initialise les composants graphiques du formulaire.
        /// </summary>
        private void InitializeComposant()
        {
            this.SuspendLayout();
            // 
            // ColorationV2
            // 
            this.AutoScaleDimensions = new SizeF(8F, 20F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.WindowState = FormWindowState.Maximized;
            this.Name = "ColorationV2";
            this.Text = "ColorationV2";
            this.ResumeLayout(false);
        }
    }
}