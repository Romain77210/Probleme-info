﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Globalization;

namespace GrapheApp
{
    /// <summary>
    /// classe principale de la fenêtre utilisateur
    /// permet de charger les données et de calculer les chemins avec Dijkstra et Bellman-Ford
    /// </summary>
    public class FenetreGraphe : Form
    {

        List<Station> stations = new List<Station>();
        List<Lien> liens = new List<Lien>();
        List<Station> chemin = new List<Station>();

        // boutons
        ComboBox cbDepart, cbArrivee;
        Button btnCharger, btnChemin, btnBellmanFord;

        /// <summary>
        /// Constructeur de la fenêtre. Initialise les éléments de l'interface.
        /// </summary>
        public FenetreGraphe(string s1 ,string s2)
        {
            // Configuration générale de la fenêtre
            this.Text = "Carte Métro";
            this.ClientSize = new Size(1000, 800);
            this.BackColor = Color.White;

            // Appelé à chaque rafraîchissement de la fenêtre (dessin du graphe)
            this.Paint += (s, e) => Dessinateur.DessinerCarte(e.Graphics, stations, liens, chemin, this.ClientSize);

            // Bouton de chargement du graphe
            btnCharger = new Button() { Text = "Charger", Location = new Point(20, 20), Size = new Size(150, 40) };

            btnCharger.Click += (s, e) =>
            {
                stations = Donnees.ChargerStations("MetroParis.csv", cbDepart, cbArrivee);
                liens = Donnees.ChargerLiens("MetroLiaisons_Lisible.csv", stations);
                chemin = new List<Station>(); // On vide le chemin

                // Vérifier les valeurs de s1 et s2
                MessageBox.Show($"s1 : {s1}");
                MessageBox.Show($"s2 : {s2}");

                // Sélectionner s1 et s2 manuellement
                foreach (var item in cbDepart.Items)
                {
                    if (item.ToString() == s1)
                    {
                        cbDepart.SelectedItem = item;
                        break;
                    }
                }
                foreach (var item in cbArrivee.Items)
                {
                    if (item.ToString() == s2)
                    {
                        cbArrivee.SelectedItem = item;
                        break;
                    }
                }

                this.Refresh();
            }; // new

            btnCharger.Click += (s, e) =>
            {
                stations = Donnees.ChargerStations("MetroParis.csv", cbDepart, cbArrivee);
                liens = Donnees.ChargerLiens("MetroLiaisons_Lisible.csv", stations);
                chemin = new List<Station>(); // On vide le chemin

                // Sélectionner s1 et s2 manuellement
                foreach (var item in cbDepart.Items)
                {
                    if (item.ToString() == s1)
                    {
                        cbDepart.SelectedItem = item;
                        break;
                    }
                }
                foreach (var item in cbArrivee.Items)
                {
                    if (item.ToString() == s2)
                    {
                        cbArrivee.SelectedItem = item;
                        break;
                    }
                }

                this.Refresh();
            }; // new


            /*btnCharger.Click += (s, e) =>
            {
                stations = Donnees.ChargerStations("MetroParis.csv", cbDepart, cbArrivee);
                liens = Donnees.ChargerLiens("MetroLiaisons_Lisible.csv", stations);
                chemin = new List<Station>(); // On vide le chemin
                this.Refresh();
            };*/


            this.Controls.Add(btnCharger);

            // Sélecteurs de station de départ et d'arrivée
            cbDepart = new ComboBox() { Location = new Point(200, 20), Size = new Size(250, 30), DropDownStyle = ComboBoxStyle.DropDownList };
            cbArrivee = new ComboBox() { Location = new Point(470, 20), Size = new Size(250, 30), DropDownStyle = ComboBoxStyle.DropDownList };
            this.Controls.Add(cbDepart);
            this.Controls.Add(cbArrivee);

            // Bouton pour lancer Dijkstra
            btnChemin = new Button() { Text = "Dijkstra", Location = new Point(740, 20), Size = new Size(100, 40) };
            btnChemin.Click += (s, e) => LancerCalcul("dijkstra");
            this.Controls.Add(btnChemin);

            // Bouton pour lancer Bellman-Ford
            btnBellmanFord = new Button() { Text = "Bellman-Ford", Location = new Point(850, 20), Size = new Size(120, 40) };
            btnBellmanFord.Click += (s, e) => LancerCalcul("bellman");
            this.Controls.Add(btnBellmanFord);
        }

        void LancerCalcul(string algo)
        {
            if (cbDepart.SelectedItem == null || cbArrivee.SelectedItem == null)
            {
                MessageBox.Show("Choisis une station de départ et d'arrivée.");
                return;
            }

            var depart = stations.First(s => s.Nom == cbDepart.SelectedItem.ToString());
            var arrivee = stations.First(s => s.Nom == cbArrivee.SelectedItem.ToString());

            chemin = algo == "dijkstra"
                ? Algorithmes.Dijkstra(stations, liens, depart, arrivee)
                : Algorithmes.BellmanFord(stations, liens, depart, arrivee);

            if (chemin != null && chemin.Count > 0)
            {
                double total = 0;
                string message = "";
                string ligneActuelle = chemin[0].Lignes.First();
                message += $"Prendre la ligne {ligneActuelle} à {chemin[0].Nom}\n";

                for (int i = 0; i < chemin.Count - 1; i++)
                {
                    var l = liens.FirstOrDefault(li => li.Contient(chemin[i], chemin[i + 1]));
                    if (l != null) total += l.Duree;

                    var lignesCommune = chemin[i].Lignes.Intersect(chemin[i + 1].Lignes).ToList();
                    string prochaineLigne = lignesCommune.Any() ? lignesCommune.First() : chemin[i + 1].Lignes.First();

                    if (prochaineLigne != ligneActuelle)
                    {
                        message += $"Changer pour la ligne {prochaineLigne} à {chemin[i].Nom}\n";
                        ligneActuelle = prochaineLigne;
                    }
                }

                message += $"Descendre à {chemin.Last().Nom}\n";
                message += $"Temps total : {total} min";

                MessageBox.Show(message);
            }
            else
            {
                MessageBox.Show("Pas de chemin trouvé.");
            }

            this.Refresh();
        }
    }
}
