SET sql_safe_updates=0;
DROP DATABASE IF EXISTS projet;
CREATE DATABASE IF NOT EXISTS projet;
USE projet;

-- -------------------------------
-- Création des tables
-- -------------------------------

CREATE TABLE utilisateur(
   id_utilisateur INT,
   Prénom VARCHAR(50),
   Nom VARCHAR(50),
   Téléphone INT,
   Mail VARCHAR(50),
   Mot_de_passe VARCHAR(50),
   Adresse_postale VARCHAR(255),
   PRIMARY KEY(id_utilisateur)
);

CREATE TABLE Cuisinier(
   Id_Cuisinier INT,
   id_utilisateur INT NOT NULL,
   PRIMARY KEY(Id_Cuisinier),
   UNIQUE(id_utilisateur),
   FOREIGN KEY(id_utilisateur) REFERENCES utilisateur(id_utilisateur) 
);

CREATE TABLE Client(
   Id_Client INT,
   id_utilisateur INT NOT NULL,
   PRIMARY KEY(Id_Client),
   UNIQUE(id_utilisateur),
   FOREIGN KEY(id_utilisateur) REFERENCES utilisateur(id_utilisateur)
);

CREATE TABLE Plat(
   Nom_plat VARCHAR(50),
   Prix INT,
   Nationalité VARCHAR(50),
   Date_de_fabrication DATETIME,
   Date_de_péremption DATETIME,
   Nbr_part INT,
   Id_Cuisinier INT NOT NULL,
   PRIMARY KEY(Nom_plat),
   FOREIGN KEY(Id_Cuisinier) REFERENCES Cuisinier(Id_Cuisinier)
);

CREATE TABLE Commande(
   Id_Commande INT auto_increment,
   Date_commande DATETIME,
   Prix INT,
   Temps DATETIME,
   Statut VARCHAR(50),
   Id_Cuisinier INT NOT NULL,
   Id_Client INT NOT NULL,
   PRIMARY KEY(Id_Commande),
   FOREIGN KEY(Id_Cuisinier) REFERENCES Cuisinier(Id_Cuisinier),
   FOREIGN KEY(Id_Client) REFERENCES Client(Id_Client)
);

CREATE TABLE avis(
   Id_avis INT,
   Titre VARCHAR(50),
   Commentaire TEXT,
   Note INT,
   Id_Client INT NOT NULL,
   Id_Cuisinier INT NOT NULL,
   PRIMARY KEY(Id_avis),
   FOREIGN KEY(Id_Client) REFERENCES Client(Id_Client),
   FOREIGN KEY(Id_Cuisinier) REFERENCES Cuisinier(Id_Cuisinier)
);

CREATE TABLE Ingrédient(
   Nom VARCHAR(50),
   Origine VARCHAR(50),
   Régime_alimentaire VARCHAR(50),
   certification VARCHAR(50),
   PRIMARY KEY(Nom)
);

CREATE TABLE Plat_Ingredient (
   Nom_plat VARCHAR(50),
   Nom_ingredient VARCHAR(50),
   PRIMARY KEY (Nom_plat, Nom_ingredient),
   FOREIGN KEY (Nom_plat) REFERENCES Plat(Nom_plat),
   FOREIGN KEY (Nom_ingredient) REFERENCES Ingrédient(Nom)
);

CREATE TABLE Commande_Plat(
   Id_Commande INT,
   Nom_plat VARCHAR(50),
   adresse_liv VARCHAR(50),
   PRIMARY KEY(Id_Commande, Nom_plat),
   FOREIGN KEY(Nom_plat) REFERENCES Plat(Nom_plat),
   FOREIGN KEY(Id_Commande) REFERENCES Commande(Id_Commande)
);

-- -------------------------------
-- Peuplement utilisateur
-- -------------------------------

INSERT INTO utilisateur (id_utilisateur, Prénom, Nom, Téléphone, Mail, Mot_de_passe, Adresse_postale) VALUES
(200001, 'democu', 'roycui', 612345678, 'democu@', 'demo', 'Porte Maillot'),
(200002, 'Claire', 'Martin', 612345679, 'claire.martin@mail.com', '56', 'Buzenval'),
(200003, 'Paul', 'Durand', 612345680, 'paul.durand@mail.com', 'mdp789', 'Arts et Métiers'),
(200004, 'Sophie', 'Lemoine', 612345681, 'sophie.lemoine@mail.com', 'mdp321', 'Quai de la Rapée'),
(200005, 'Luc', 'Bernard', 612345682, 'luc.bernard@mail.com', 'mdp654', 'Exelmans'),
(200006, 'Patrick', 'Dupuis', 612345700, 'patrick.dupuis@mail.com', 'mdp100', 'Dugommier'),
(200007, 'Isabelle', 'Lambert', 612345701, 'isabelle.lambert@mail.com', 'mdp101', 'Couronnes'),
(200008, 'Olivier', 'Marchal', 612345702, 'olivier.marchal@mail.com', 'mdp102', 'Chardon Lagache'),
(200009, 'Sabrina', 'Petit', 612345703, 'sabrina.petit@mail.com', 'mdp103', 'Quai de la Gare'),
(200010, 'Vincent', 'Moreau', 612345704, 'vincent.moreau@mail.com', 'mdp104', 'Bréguet-Sabin'),

(100001, 'democl', 'roycl', 612345683, 'democl@', 'demo', 'Porte de Clignancourt'),
(100002, 'Julien', 'Robert', 612345684, 'julien.robert@mail.com', 'mdp159', 'Villiers'),
(100003, 'Laura', 'Richard', 612345685, 'laura.richard@mail.com', 'mdp753', 'Sèvres-Lecourbe'),
(100004, 'Antoine', 'Morel', 612345686, 'antoine.morel@mail.com', 'mdp852', 'Opéra'),
(100005, 'Camille', 'Garcia', 612345687, 'camille.garcia@mail.com', 'mdp951', 'Botzaris'),
(100006, 'Lucas', 'Blanc', 612345688, 'lucas.blanc@mail.com', 'mdp147', 'Place Monge'),
(100007, 'Manon', 'Guerin', 612345689, 'manon.guerin@mail.com', 'mdp258', 'Les Gobelins'),
(100008, 'Nathan', 'Faure', 612345690, 'nathan.faure@mail.com', 'mdp369', 'Avenue Emile Zola'),
(100009, 'Sarah', 'Chevalier', 612345691, 'sarah.chevalier@mail.com', 'mdp1234', 'Assemblée Nationale'),
(100010, 'David', 'Lopez', 612345692, 'david.lopez@mail.com', 'mdp4321', 'Boucicaut'),
(100011, 'Julie', 'Fontaine', 612345693, 'julie.fontaine@mail.com', 'mdp5678', 'Cour Saint-Emilion'),
(100012, 'Matthieu', 'Leclerc', 612345694, 'matthieu.leclerc@mail.com', 'mdp8765', 'Danube'),
(100013, 'Anaïs', 'Benoit', 612345695, 'anais.benoit@mail.com', 'mdp1122', 'Montparnasse Bienvenüe'),
(100014, 'Thomas', 'Marchand', 612345696, 'thomas.marchand@mail.com', 'mdp2211', 'Place des Fêtes'),
(100015, 'Elodie', 'Noel', 612345697, 'elodie.noel@mail.com', 'mdp3344', 'Volontaires'),
(100016, 'Chloe', 'Renard', 612345705, 'chloe.renard@mail.com', 'mdp105', 'Passy'),
(100017, 'Alexandre', 'Perrot', 612345706, 'alexandre.perrot@mail.com', 'mdp106', 'Commerce'),
(100018, 'Celine', 'Barbier', 612345707, 'celine.barbier@mail.com', 'mdp107', 'Porte des Lilas'),
(100019, 'Damien', 'Girard', 612345708, 'damien.girard@mail.com', 'mdp108', 'Porte d\'Ivry'),
(100020, 'Valerie', 'Dumont', 612345709, 'valerie.dumont@mail.com', 'mdp109', 'Porte de Versailles');




-- -------------------------------
-- Peuplement Cuisiniers et Clients
-- -------------------------------

INSERT INTO Cuisinier VALUES
(200001, 200001), (200002, 200002), (200003, 200003), (200004, 200004), (200005, 200005),
(200006, 200006), (200007, 200007), (200008, 200008), (200009, 200009), (200010, 200010);

INSERT INTO Client VALUES
(100001, 100001), (100002, 100002), (100003, 100003), (100004, 100004), (100005, 100005),
(100006, 100006), (100007, 100007), (100008, 100008), (100009, 100009), (100010, 100010),
(100011, 100011), (100012, 100012), (100013, 100013), (100014, 100014), (100015, 100015),
(100016, 100016), (100017, 100017), (100018, 100018), (100019, 100019), (100020, 100020);

-- Peuplement Ingrédient
INSERT INTO Ingrédient VALUES
('Tomate', 'France', 'Végétalien', 'BIO'),
('Poulet', 'France', 'Omnivore', 'Label Rouge'),
('Mozzarella', 'Italie', 'Végétarien', 'AOP'),
('Basilic', 'Italie', 'Végétalien', 'BIO'),
('Boeuf', 'Argentine', 'Omnivore', 'AB'),
('Pâtes', 'Italie', 'Végétarien', 'BIO'),
('Oignon', 'Espagne', 'Végétalien', 'BIO'),
('Saumon', 'Norvège', 'Pescétarien', 'ASC'),
('Courgette', 'France', 'Végétalien', 'BIO'),
('Ail', 'Espagne', 'Végétalien', 'BIO'),
('Crevette', 'Vietnam', 'Pescétarien', 'ASC'),
('Riz', 'Inde', 'Végétalien', 'BIO'),
('Fromage de chèvre', 'France', 'Végétarien', 'AOP'),
('Poivron', 'Espagne', 'Végétalien', 'BIO'),
('Pomme de terre', 'France', 'Végétalien', 'BIO'),
('Champignon', 'Pologne', 'Végétalien', 'BIO'),
('Thon', 'Espagne', 'Pescétarien', 'MSC'),
('Courge', 'France', 'Végétalien', 'BIO'),
('Porc', 'France', 'Omnivore', 'Label Rouge'),
('Laitue', 'France', 'Végétalien', 'BIO');

-- Peuplement Plat
INSERT INTO Plat VALUES
('Pizza Margherita', 12, 'Italie', '2025-05-01 10:00:00', '2025-05-05 10:00:00', 2, 200001),
('Poulet Basquaise', 15, 'France', '2025-05-01 11:00:00', '2025-05-05 11:00:00', 3, 200002),
('Lasagnes', 14, 'Italie', '2025-05-01 12:00:00', '2025-05-06 12:00:00', 4, 200003),
('Burger Maison', 13, 'USA', '2025-05-02 10:00:00', '2025-05-07 10:00:00', 2, 200004),
('Saumon Teriyaki', 17, 'Japon', '2025-05-02 11:00:00', '2025-05-06 11:00:00', 2, 200005),
('Spaghetti Carbonara', 12, 'Italie', '2025-05-03 12:00:00', '2025-05-07 12:00:00', 2, 200001),
('Couscous Royal', 18, 'Maroc', '2025-05-03 13:00:00', '2025-05-08 13:00:00', 5, 200002),
('Tacos', 10, 'Mexique', '2025-05-04 10:00:00', '2025-05-08 10:00:00', 2, 200003),
('Paella', 16, 'Espagne', '2025-05-04 11:00:00', '2025-05-09 11:00:00', 3, 200004),
('Boeuf Bourguignon', 17, 'France', '2025-05-04 12:00:00', '2025-05-09 12:00:00', 4, 200005);

-- Peuplement Plat_Ingredient
INSERT INTO Plat_Ingredient VALUES
('Pizza Margherita', 'Tomate'),
('Pizza Margherita', 'Mozzarella'),
('Pizza Margherita', 'Basilic'),
('Poulet Basquaise', 'Poulet'),
('Poulet Basquaise', 'Poivron'),
('Lasagnes', 'Boeuf'),
('Lasagnes', 'Tomate'),
('Lasagnes', 'Mozzarella'),
('Burger Maison', 'Boeuf'),
('Burger Maison', 'Tomate'),
('Saumon Teriyaki', 'Saumon'),
('Saumon Teriyaki', 'Riz'),
('Spaghetti Carbonara', 'Pâtes'),
('Spaghetti Carbonara', 'Oignon'),
('Couscous Royal', 'Poulet'),
('Couscous Royal', 'Courgette'),
('Tacos', 'Poulet'),
('Tacos', 'Poivron'),
('Paella', 'Crevette'),
('Paella', 'Riz'),
('Boeuf Bourguignon', 'Boeuf'),
('Boeuf Bourguignon', 'Oignon');

-- -------------------------------
-- Peuplement Commande
-- -------------------------------

   -- Id_Commande , Date_commande,  Prix,   Temps,   Statut ,   Id_Cuisinier ,   Id_Client L,
INSERT INTO Commande VALUES
(1, '2025-05-01 14:00:00', 30, '2025-05-01 14:30:00', 'Livrée', 200001, 100006),
(2, '2025-05-02 15:00:00', 33, '2025-05-02 15:30:00', 'Livrée', 200002, 100007),
(3, '2025-05-02 16:00:00', 40, '2025-05-02 16:30:00', 'En préparation', 200003, 100008),
(4, '2025-05-03 17:00:00', 25, '2025-05-03 17:30:00', 'Livrée', 200004, 100009),
(5, '2025-05-03 18:00:00', 32, '2025-05-03 18:30:00', 'Livrée', 200005, 100010),
(6, '2025-05-04 12:00:00', 36, '2025-05-04 12:30:00', 'Livrée', 200001, 100011),
(7, '2025-05-04 13:00:00', 29, '2025-05-04 13:30:00', 'Livrée', 200002, 100012),
(8, '2025-05-04 14:00:00', 39, '2025-05-04 14:30:00', 'Livrée', 200003, 100013),
(9, '2025-05-05 15:00:00', 28, '2025-05-05 15:30:00', 'Livrée', 200004, 100014),
(10, '2025-05-05 16:00:00', 35, '2025-05-05 16:30:00', 'Livrée', 200005, 100015),
(11, '2025-05-06 12:00:00', 27, '2025-05-06 12:30:00', 'Livrée', 200001, 100016),
(12, '2025-05-06 13:00:00', 45, '2025-05-06 13:30:00', 'Livrée', 200002, 100017),
(13, '2025-05-06 14:00:00', 38, '2025-05-06 14:30:00', 'En préparation', 200003, 100018),
(14, '2025-05-06 15:00:00', 24, '2025-05-06 15:30:00', 'Livrée', 200004, 100019),
(15, '2025-05-06 16:00:00', 31, '2025-05-06 16:30:00', 'Livrée', 200005, 100020),
(16, '2025-05-07 12:00:00', 33, '2025-05-07 12:30:00', 'Livrée', 200001, 100001),
(17, '2025-05-07 13:00:00', 42, '2025-05-07 13:30:00', 'Livrée', 200002, 100002),
(18, '2025-05-07 14:00:00', 29, '2025-05-07 14:30:00', 'Livrée', 200003, 100003),
(19, '2025-05-07 15:00:00', 37, '2025-05-07 15:30:00', 'Livrée', 200004, 100004),
(20, '2025-05-07 16:00:00', 41, '2025-05-07 16:30:00', 'Livrée', 200005, 100005),
(21, '2025-05-07 16:00:00', 41, '2025-05-07 16:30:00', 'Livrée', 200009, 100005),
(50, '2025-05-07 16:00:00', 41, '2025-05-07 16:30:00', 'Livrée', 200001, 100005),
(51, '2025-05-07 16:00:00', 41, '2025-05-07 16:30:00', 'Livrée', 200001, 100001);
-- -------------------------------
-- Peuplement Commande_Plat (plusieurs plats par commande)
-- -------------------------------



   -- Id_Commande,   Nom_plat ,   adresse_liv 
   
   INSERT INTO Commande_Plat VALUES (51, 'Pizza Margherita', '12 rue de Paris');
   INSERT INTO Commande_Plat VALUES (51, 'Spaghetti Carbonara', '12 rue de Paris');
-- Commande 1
INSERT INTO Commande_Plat VALUES (1, 'Pizza Margherita', '12 rue de Paris');
INSERT INTO Commande_Plat VALUES (1, 'Spaghetti Carbonara', '12 rue de Paris');

-- Commande 2
INSERT INTO Commande_Plat VALUES (2, 'Poulet Basquaise', '34 avenue Victor Hugo');
INSERT INTO Commande_Plat VALUES (2, 'Couscous Royal', '34 avenue Victor Hugo');

-- Commande 3
INSERT INTO Commande_Plat VALUES (3, 'Lasagnes', '56 rue Lafayette');
INSERT INTO Commande_Plat VALUES (3, 'Tacos', '56 rue Lafayette');
INSERT INTO Commande_Plat VALUES (3, 'Paella', '56 rue Lafayette');

-- Commande 4
INSERT INTO Commande_Plat VALUES (4, 'Burger Maison', '78 rue de Lyon');
INSERT INTO Commande_Plat VALUES (4, 'Pizza Margherita', '78 rue de Lyon');

-- Commande 5
INSERT INTO Commande_Plat VALUES (5, 'Saumon Teriyaki', '90 avenue des Champs');
INSERT INTO Commande_Plat VALUES (5, 'Boeuf Bourguignon', '90 avenue des Champs');

-- Commande 6
INSERT INTO Commande_Plat VALUES (6, 'Spaghetti Carbonara', '10 rue Saint Denis');
INSERT INTO Commande_Plat VALUES (6, 'Couscous Royal', '10 rue Saint Denis');

-- Commande 7
INSERT INTO Commande_Plat VALUES (7, 'Tacos', '11 rue des Rosiers');
INSERT INTO Commande_Plat VALUES (7, 'Lasagnes', '11 rue des Rosiers');

-- Commande 8
INSERT INTO Commande_Plat VALUES (8, 'Paella', '12 rue Oberkampf');
INSERT INTO Commande_Plat VALUES (8, 'Pizza Margherita', '12 rue Oberkampf');
INSERT INTO Commande_Plat VALUES (8, 'Poulet Basquaise', '12 rue Oberkampf');

-- Commande 9
INSERT INTO Commande_Plat VALUES (9, 'Burger Maison', '13 rue Mouffetard');
INSERT INTO Commande_Plat VALUES (9, 'Spaghetti Carbonara', '13 rue Mouffetard');

-- Commande 10
INSERT INTO Commande_Plat VALUES (10, 'Saumon Teriyaki', '14 rue Cler');
INSERT INTO Commande_Plat VALUES (10, 'Tacos', '14 rue Cler');

-- Commande 11
INSERT INTO Commande_Plat VALUES (11, 'Lasagnes', '15 rue de Sèvres');
INSERT INTO Commande_Plat VALUES (11, 'Paella', '15 rue de Sèvres');

-- Commande 12
INSERT INTO Commande_Plat VALUES (12, 'Pizza Margherita', '16 rue du Bac');
INSERT INTO Commande_Plat VALUES (12, 'Poulet Basquaise', '16 rue du Bac');
INSERT INTO Commande_Plat VALUES (12, 'Couscous Royal', '16 rue du Bac');

-- Commande 13
INSERT INTO Commande_Plat VALUES (13, 'Burger Maison', '17 rue du Cherche-Midi');
INSERT INTO Commande_Plat VALUES (13, 'Saumon Teriyaki', '17 rue du Cherche-Midi');

-- Commande 14
INSERT INTO Commande_Plat VALUES (14, 'Spaghetti Carbonara', '18 avenue de Breteuil');
INSERT INTO Commande_Plat VALUES (14, 'Tacos', '18 avenue de Breteuil');

-- Commande 15
INSERT INTO Commande_Plat VALUES (15, 'Lasagnes', '19 boulevard Raspail');
INSERT INTO Commande_Plat VALUES (15, 'Paella', '19 boulevard Raspail');

-- Commande 16
INSERT INTO Commande_Plat VALUES (16, 'Pizza Margherita', '20 rue Lafayette');
INSERT INTO Commande_Plat VALUES (16, 'Boeuf Bourguignon', '20 rue Lafayette');

-- Commande 17
INSERT INTO Commande_Plat VALUES (17, 'Poulet Basquaise', '21 avenue Carnot');
INSERT INTO Commande_Plat VALUES (17, 'Couscous Royal', '21 avenue Carnot');

-- Commande 18
INSERT INTO Commande_Plat VALUES (18, 'Burger Maison', '22 rue Nationale');
INSERT INTO Commande_Plat VALUES (18, 'Saumon Teriyaki', '22 rue Nationale');

-- Commande 19
INSERT INTO Commande_Plat VALUES (19, 'Spaghetti Carbonara', '23 rue Voltaire');
INSERT INTO Commande_Plat VALUES (19, 'Tacos', '23 rue Voltaire');
INSERT INTO Commande_Plat VALUES (19, 'Paella', '23 rue Voltaire');

-- Commande 20
INSERT INTO Commande_Plat VALUES (20, 'Lasagnes', '24 avenue de France');
INSERT INTO Commande_Plat VALUES (20, 'Pizza Margherita', '24 avenue de France');


INSERT INTO avis VALUES
(1, 'Excellent', 'La pizza était délicieuse.', 5, 100006, 200001),
(6, 'pas ouf', 'La pizza était délicieuse.', 2, 100008, 200001),
(2, 'Très bon', 'Le poulet était tendre.', 4, 100007, 200002),
(3, 'Correct', 'Les lasagnes un peu salées.', 3, 100008, 200003),
(4, 'Délicieux', 'Burger savoureux.', 5, 100009, 200004),
(5, 'Parfait', 'Saumon parfaitement cuit.', 5, 100010, 200005);
