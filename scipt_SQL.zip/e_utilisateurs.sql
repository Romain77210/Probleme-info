CREATE DATABASE IF NOT EXISTS Projet;
USE Projet;

create user if not exists 'root'@'localhost' identified by 'root' ;
grant all on projet. * to 'root'@'localhost';

create user if not exists 'Cuisinier'@'localhost' identified by '123456' ;
GRANT SELECT, INSERT, UPDATE, DELETE ON projet.* TO 'Cuisinier'@'localhost';


create user if not exists 'Client'@'localhost' identified by '12345' ;
GRANT SELECT, INSERT ON projet.* TO 'Client'@'localhost';

-- show grants for 'Cuisinier'@'localhost';
-- show grants for 'Client'@'localhost';


-- select * from mysql.user;
