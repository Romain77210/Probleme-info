﻿namespace GrapheApp
{
    public class Station
    {
        public string Nom { get; }
        public double Longitude { get; }
        public double Latitude { get; }
        public HashSet<string> Lignes { get; }  // Ajout

        public Station(string nom, double lon, double lat)
        {
            Nom = nom;
            Longitude = lon;
            Latitude = lat;
            Lignes = new HashSet<string>();
        }
    }

    public class StationTemp
    {
        public string Nom { get; }
        public double Longitude { get; }
        public double Latitude { get; }
        public string Ligne { get; set; } // Ajout

        public StationTemp(string nom, double lon, double lat)
        {
            Nom = nom;
            Longitude = lon;
            Latitude = lat;
        }
    }
}
