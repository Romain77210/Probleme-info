using map_métro_paris;
using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace GrapheApp
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            // coloration();
           //metrocuisinier("","");



            bool connecté = false;
            while (true)  // boucle infini
            {
                Console.Clear();
                // cuisinier aussi formulaire et connexion avec root mais vous simuler envoie de mail avec mdp ensuite on passe à ici


                string uti = "", pswd = "";
                MySqlConnection maConnection = null;
                bool connec = false;
                int saisi = -1;

                int choix = -1;  // 0 inscription,  1 connexion
                Console.WriteLine("0 pour s'inscrire / 1 pour se connecter");
                choix = Saisieval(0, 1);

                if (choix == 0)  // inscription
                {
                    #region connexion_a_root
                    uti = "root";
                    pswd = "root";
                    string connectionString = $"SERVER=localhost;PORT=3306;DATABASE=projet;UID={uti};PASSWORD={pswd};";
                    maConnection = new MySqlConnection(connectionString);

                    try
                    {
                        maConnection.Open();
                        connec = true;

                    }
                    catch (MySqlException ex)
                    {
                        switch (ex.Number)
                        {
                            case 0:
                                Console.WriteLine("Impossible de se connecter au serveur.");
                                break;
                            case 1045:
                                Console.WriteLine("Mauvais identifiant ou mot de passe.");
                                break;
                            default:
                                Console.WriteLine($"Erreur MySQL : {ex.Message}");
                                break;
                        }
                    }
                    #endregion


                    #region crea_et_verif_ID_uti

                    int id_utilisateur = 0;
                    int id_Client = 0;
                    int id_Cuisinier = 0;
                    int ran = new Random().Next(100000, 999999);


                    Console.WriteLine("créé un compte cuisinier (1) ou Client (2) ?");
                    int choixrole = Saisieval(1, 2);
                    if (choixrole == 1)   // Cuisinier
                    {
                        ran = new Random().Next(200000, 299999);
                        id_utilisateur = ran;
                        id_Cuisinier = id_utilisateur;
                    }
                    else if (choixrole == 2)  // Client
                    {
                        ran = new Random().Next(100000, 199999);
                        id_Client = id_utilisateur;
                    }



                    MySqlCommand command = maConnection.CreateCommand();
                    command.CommandText = $"SELECT count(*) FROM utilisateur WHERE id_utilisateur = {id_utilisateur};";
                    object result = command.ExecuteScalar();

                    while (Convert.ToInt32(result) == 1)
                    {
                        ran = new Random().Next(300000, 399999);
                        id_utilisateur = ran;
                        command = maConnection.CreateCommand();
                        command.CommandText = $"SELECT count(*) FROM utilisateur WHERE id_utilisateur = {id_utilisateur};";
                        result = command.ExecuteScalar();
                    }
                    #endregion



                    #region insertion_utilisateur_client_cuisinier
                    Console.Clear();
                    Console.WriteLine("entrer votre prenom");
                    string prenom = Console.ReadLine();

                    Console.WriteLine("entrer votre Nom");
                    string nom = Console.ReadLine();

                    Console.WriteLine("entrer votre telephone");
                    int tel = Saisieval(0100000000, 0999999999);

                    Console.WriteLine("entrer votre mail");
                    string mail = Console.ReadLine();  //

                    #region verif_mail

                    MySqlCommand commandma = maConnection.CreateCommand();
                    commandma.CommandText = "SELECT count(*) FROM utilisateur WHERE mail = @mail";
                    commandma.Parameters.AddWithValue("@mail", mail);

                    object resultma = commandma.ExecuteScalar();

                    while (Convert.ToInt32(resultma) == 1)
                    {

                        Console.WriteLine("Entrez un autre email :");
                        mail = Console.ReadLine();

                        commandma = maConnection.CreateCommand();
                        commandma.CommandText = "SELECT count(*) FROM utilisateur WHERE mail = @mail";
                        commandma.Parameters.Clear();
                        commandma.Parameters.AddWithValue("@mail", mail);
                        resultma = commandma.ExecuteScalar();
                    }
                    #endregion



                    Console.WriteLine("entrer votre mot de passe");
                    string mdp = Console.ReadLine();

                    Console.WriteLine("entrer votre adresse postal");
                    string aposte = Console.ReadLine();


                    //insérer utilisateur
                    MySqlCommand commanduti = maConnection.CreateCommand();
                    commanduti.CommandText = @"INSERT INTO utilisateur (id_utilisateur, Prénom, Nom, Téléphone, Mail, Mot_de_passe, Adresse_postale) VALUE
                    (@id_utilisateur,@Prénom,@nom,@Téléphone,@Mail,@Mot_de_passe,@Adresse_posale);";
                    commanduti.Parameters.AddWithValue("@id_utilisateur", id_utilisateur);
                    commanduti.Parameters.AddWithValue("@Prénom", prenom);
                    commanduti.Parameters.AddWithValue("@nom", nom);
                    commanduti.Parameters.AddWithValue("@Téléphone", tel);
                    commanduti.Parameters.AddWithValue("@Mail", mail);
                    commanduti.Parameters.AddWithValue("@Mot_de_passe", mdp);
                    commanduti.Parameters.AddWithValue("@Adresse_posale", aposte);

                    commanduti.ExecuteNonQuery();
                    Console.WriteLine($"compte utilisateur ajouté");

                    // insserer cuisinier

                    if (choixrole == 1)
                    {
                        MySqlCommand commandcui = maConnection.CreateCommand();
                        commandcui.CommandText = @"INSERT INTO Cuisinier (Id_Cuisinier,id_utilisateur) VALUE
                    (@Id_Cuisinier,@id_utilisateur);";
                        commandcui.Parameters.AddWithValue("@Id_Cuisinier", id_Cuisinier);
                        commandcui.Parameters.AddWithValue("@id_utilisateur", id_utilisateur);



                        commandcui.ExecuteNonQuery();
                        Console.WriteLine($"Cuisinier ajouté");
                    }

                    // insserer Client

                    if (choixrole == 2)
                    {
                        MySqlCommand commandcli = maConnection.CreateCommand();
                        commandcli.CommandText = @"INSERT INTO Client (Id_Client,id_utilisateur) VALUE
                    (@Id_Client,@id_utilisateur);";
                        commandcli.Parameters.AddWithValue("@Id_Client", id_Client);
                        commandcli.Parameters.AddWithValue("@id_utilisateur", id_utilisateur);



                        commandcli.ExecuteNonQuery();
                        Console.WriteLine($"client client ajouté");

                    }
                    #endregion

                }  // 0 inscription

                while (!connec && choix == 1)  // 1 connexion
                {
                    Console.WriteLine("Vous etes cuisinier ou client? 1 cuisinier / 2 client / 3 admin");
                    saisi = Saisieval(0, 3);
                    if (saisi == 1)  // 1 Cuisinier 
                    {
                        Console.WriteLine("Saisir le mot de passe :");
                        uti = "Cuisinier";
                        pswd = Console.ReadLine();

                    }
                    else if (saisi == 2)    // 2 client
                    {
                        uti = "Client";
                        pswd = "12345";


                    }
                    else if (saisi == 3)  // Administrateur
                    {
                        uti = "root";
                        Console.WriteLine("Saisir le mot de passe admin :");
                        pswd = Console.ReadLine();  // root  ou admin

                    }
                    else break;

                    #region connexion
                    string connectionString = $"SERVER=localhost;PORT=3306;DATABASE=projet;UID={uti};PASSWORD={pswd};";
                    maConnection = new MySqlConnection(connectionString);

                    try
                    {
                        maConnection.Open();
                        connec = true;

                    }
                    catch (MySqlException ex)
                    {
                        switch (ex.Number)
                        {
                            case 0:
                                Console.WriteLine("Impossible de se connecter au serveur.");
                                break;
                            case 1045:
                                Console.WriteLine("Mauvais identifiant ou mot de passe.");
                                break;
                            default:
                                Console.WriteLine($"Erreur MySQL : {ex.Message}");
                                break;
                        }
                    }
                    #endregion

                } // 1 conexion (client/cuisinier/root)



                if (saisi == 1)  // cuisinier
                {

                    #region verif_cuisinier
                    bool identifié = false;
                    string mailcuisinier = "";
                    while (!identifié)
                    {
                        Console.WriteLine("adresse mail:");
                        mailcuisinier = Console.ReadLine();
                        string mdp_de_mail = $"select mot_de_passe from utilisateur u join cuisinier c on c.id_utilisateur = u.id_utilisateur where u.mail = \'{mailcuisinier}' ;";

                        Console.WriteLine("mot de passe:");
                        string mdpcuisinier = Console.ReadLine();
                        string mdpattendu = Afficher_mdp_de_mail(maConnection, mdp_de_mail);
                        if (mdpcuisinier == mdpattendu)
                        {
                            Console.WriteLine("connextion réussi");
                            Console.ReadLine();
                            identifié = true;

                        }
                        if (mdpcuisinier == "0" || mailcuisinier == "0")
                        {
                            Console.Clear();
                            break;
                        }
                        Console.Clear();

                    }
                    #endregion
                    if (identifié)
                    {
                        Console.Clear();
                        LancerInterfaceCuisinier(maConnection, mailcuisinier);
                    }
                } // cuisinier

                else if (saisi == 2)  // client
                {
                    #region verif_client

                    bool identifié = false;
                    string mailclient = "0";
                    while (!identifié)
                    {
                        Console.WriteLine("adresse mail:");
                        mailclient = Console.ReadLine();
                        string mdp_de_mail = $"select mot_de_passe from utilisateur u join client c on c.id_utilisateur = u.id_utilisateur where u.mail = \'{mailclient}' ;";

                        Console.WriteLine("mot de passe:");
                        string mdpclient = Console.ReadLine();
                        string mdpattendu = Afficher_mdp_de_mail(maConnection, mdp_de_mail);
                        if (mdpclient == mdpattendu)
                        {
                            Console.WriteLine("connextion réussi");
                            Console.ReadLine();
                            identifié = true;
                        }
                        if (mdpclient == "0" || mailclient == "0")
                        {
                            Console.Clear();
                            break;
                        }
                        Console.Clear();

                    }
                    #endregion
                    if (identifié)
                    {
                        Console.Clear();
                        LancerInterfaceClient(maConnection, mailclient);
                    }
                } // client

                else if (saisi == 3) // admin
                {

                    Console.WriteLine("connexion admin :");
                    LancerInterfaceAdmin(maConnection);

                }  // admin

                if (connec)
                {
                    maConnection.Close();
                }

            }
        }

        static void metrocuisinier(string s1, string s2)
        {

           
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FenetreGraphe(s1, s2));


        }
        static void coloration()
        {

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new ColorationV2());

        }







        static void LancerInterfaceClient(MySqlConnection maConnection, string mailclient)
        {
            List<(string NomPlat, int NbParts, string AdresseLivraison)> panier = new List<(string, int, string)>(); // Liste de tuples
            string adresseLivraison = "";

            int idCuisinier = 0;
            int idClient = IDclientdepuismail(maConnection, mailclient);

            if (idClient == 0)
            {
                Console.WriteLine("Client non trouvé !");
                return;
            }

            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== Interface Client ===");
                Console.WriteLine("Voulez-vous ajouter un plat ou valider le panier ? (voir avis/laisser avis/plat/panier/quitter)");
                string choix = Console.ReadLine().ToLower();

                if (choix == "voir avis")
                {
                    string s45 = "SELECT a.Titre, a.Commentaire, a.Note, u.Prénom, u.Nom\r\nFROM avis a\r\nJOIN Cuisinier c ON a.Id_Cuisinier = c.Id_Cuisinier\r\nJOIN utilisateur u ON c.id_utilisateur = u.id_utilisateur\r\norder by c.Id_Cuisinier;";
                    AfficherResultatsRequete(maConnection, s45);
                    Console.ReadLine();
                }

                if (choix == "laisser avis")
                {
                    Console.Clear();
                    Console.WriteLine("=== Laisser un avis ===");

                    // Saisir le titre
                    Console.WriteLine("Titre de l'avis : ");
                    string titre = Console.ReadLine();

                    // Saisir le commentaire
                    Console.WriteLine("Commentaire : ");
                    string commentaire = Console.ReadLine();

                    // Saisir la note
                    int note;
                    while (true)
                    {
                        Console.WriteLine("Note (0 à 5) : ");
                        if (int.TryParse(Console.ReadLine(), out note) && note >= 0 && note <= 5)
                            break;
                        else
                            Console.WriteLine("Note invalide. Entrez un nombre entre 0 et 5.");
                    }

                    // 🔎 --- Afficher tous les cuisiniers ---
                    Console.WriteLine("\nListe des cuisiniers disponibles :");
                    MySqlCommand cmdListeCuisiniers = maConnection.CreateCommand();
                    cmdListeCuisiniers.CommandText = @"
        SELECT cu.Id_Cuisinier, u.Prénom, u.Nom 
        FROM Cuisinier cu
        JOIN utilisateur u ON cu.id_utilisateur = u.id_utilisateur;";

                    using (var reader = cmdListeCuisiniers.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int id = reader.GetInt32(0);
                            string prenom = reader.GetString(1);
                            string nom = reader.GetString(2);
                            Console.WriteLine($"ID : {id} | {prenom} {nom}");
                        }
                    }

                    // 🔎 --- Saisir l'ID du cuisinier ---
                    Console.WriteLine("\nEntrez l'ID du cuisinier à qui vous voulez donner l'avis : ");
                    int idCuisinieravi = Convert.ToInt32(Console.ReadLine());

                    // Générer un Id_avis unique
                    Random rand = new Random();
                    int idAvis = rand.Next(10000, 99999);

                    // Préparer la commande SQL
                    var cmdAvis = maConnection.CreateCommand();
                    cmdAvis.CommandText = @"INSERT INTO avis (Id_avis, Titre, Commentaire, Note, Id_Client, Id_Cuisinier)
                            VALUES (@Id_avis, @Titre, @Commentaire, @Note, @Id_Client, @Id_Cuisinier);";

                    cmdAvis.Parameters.AddWithValue("@Id_avis", idAvis);
                    cmdAvis.Parameters.AddWithValue("@Titre", titre);
                    cmdAvis.Parameters.AddWithValue("@Commentaire", commentaire);
                    cmdAvis.Parameters.AddWithValue("@Note", note);
                    cmdAvis.Parameters.AddWithValue("@Id_Client", idClient);    // variable déjà connue
                    cmdAvis.Parameters.AddWithValue("@Id_Cuisinier", idCuisinieravi);

                    try
                    {
                        cmdAvis.ExecuteNonQuery();
                        Console.WriteLine("\nAvis inséré avec succès !");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Erreur lors de l'insertion de l'avis : " + ex.Message);
                    }

                    Console.ReadLine();
                }



                if (choix == "quitter")
                {
                    break;
                }

                if (choix == "plat")
                {
                    string platChoisi;

                    // Si c'est le premier plat, on affiche tous les plats
                    if (idCuisinier == 0)
                    {
                        platChoisi = AfficherPlats(maConnection); // Tous les plats
                        idCuisinier = IDcuisinierdepuisplat(maConnection, platChoisi); // On récupère l'ID du cuisinier
                    }
                    else
                    {
                        // Si un cuisinier est déjà choisi, on affiche que ses plats
                        platChoisi = AfficherPlatsducuisiner(maConnection, idCuisinier);
                    }

                    if (string.IsNullOrEmpty(platChoisi))
                    {
                        Console.WriteLine("Aucun plat sélectionné");
                        continue;
                    }

                    Console.WriteLine("Combien de parts ?");
                    int nbParts;
                    bool ok = int.TryParse(Console.ReadLine(), out nbParts);

                    if (!ok || nbParts <= 0)
                    {
                        Console.WriteLine("Nombre invalide.");
                        continue;
                    }

                    Console.Clear();
                    Afficher_Ingrédient(maConnection, platChoisi);
                    Afficher_avis_du_plat_du_cuisinier(maConnection, platChoisi);

                    // Demander l'adresse de livraison spécifique pour ce plat
                    Console.WriteLine("Entrez l'adresse de livraison pour ce plat :");
                    string adresseLiv = "au " + Console.ReadLine();

                    // Ajouter le plat au panier (tuple)
                    panier.Add((platChoisi, nbParts, adresseLiv));

                    Console.WriteLine("Plat ajouté au panier !");
                }
                else if (choix == "panier")
                {
                    Console.Clear();
                    Console.WriteLine("Voici le contenu de votre panier :");

                    int prixTotal = 0;

                    foreach (var plat in panier)
                    {
                        Console.WriteLine($"{plat.NomPlat} x{plat.NbParts} (Adresse : {plat.AdresseLivraison})");
                        prixTotal += plat.NbParts * PrixDuPlat(maConnection, plat.NomPlat, idCuisinier); // Ajouter la méthode PrixDuPlat pour calculer le prix total
                    }

                    Console.WriteLine($"Prix total : {prixTotal} euros");
                    Console.WriteLine("Voulez-vous valider votre commande ? (oui/non)");
                    string confirmation = Console.ReadLine().ToLower();
                    if (confirmation == "oui")
                    {
                        ticketdecaisse(maConnection, idClient, idCuisinier, panier, prixTotal);
                        Console.WriteLine("Commande validée !");
                    }
                    else
                    {
                        Console.WriteLine("Retour au menu principal...");
                    }

                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Choix invalide. Tapez 'plat' ou 'panier'.");
                }
            }
        }

        static void LancerInterfaceCuisinier(MySqlConnection maConnection, string mailCuisinier)
        {
            while (true)
            {
                while(true)
                {
                    Console.Clear();
                    Console.WriteLine("interface cuisinier");
                    Console.WriteLine("1. Ajouter un plat");
                    Console.WriteLine("2. Voir le menu");
                    Console.WriteLine("3. Ajouter un ingrédient");
                    Console.WriteLine("4. Mettre à jour le statut d'une commande");
                    Console.WriteLine("5. Livraison");
                    Console.WriteLine("6. afficher avis");
                    Console.WriteLine("7. Quitter");
                    string choix = Console.ReadLine();
                    if (choix == "1")
                {
                    Console.WriteLine("Votre Id cuisinier :");
                    string Id_Cuisinier = Console.ReadLine();
                    Ajoutplat(maConnection, Id_Cuisinier);
                        choix = "0";
                }
                else if (choix == "2")
                {
                    Console.Clear();
                    Afficherplat2(maConnection);
                    Console.WriteLine("Souhaitez-vous supprimer un plat ? (oui/non)");
                    string verif = Saisiestring("oui", "non");

                    if (verif == "oui")
                    {
                        nuc(maConnection);
                        Console.WriteLine("Votre plat a été supprimé.");
                    }
                    else
                    {
                        Console.WriteLine("Souhaitez-vous afficher les ingrédients d'un plat ? (oui/non)");
                        string verif2 = Saisiestring("oui", "non");

                        if (verif2 == "oui")
                        {
                            Console.Clear();
                            Afficherplat2(maConnection);
                            Console.WriteLine("Sélectionner un plat :");
                            string platchoisi = Console.ReadLine();
                            Afficher_Ingrédient(maConnection, platchoisi);
                            Console.ReadLine();
                        }
                    }

                        choix = "0";
                    }
                else if (choix == "3")
                {
                    Console.Clear();
                    Afficherplat2(maConnection);
                    Console.WriteLine("Pour quel plat souhaitez-vous ajouter un ingrédient ?");
                    string platchoisi = Console.ReadLine();
                    AjoutIngredient(maConnection, platchoisi);

                    Console.WriteLine("Souhaitez-vous afficher la liste des ingrédients ? (oui/non)");
                    string verif = Console.ReadLine();

                    if (verif == "oui")
                    {
                        Afficher_Ingrédient(maConnection, platchoisi);
                    }
                        choix = "0";
                    }

                else if (choix == "4")
                {
                    Console.Clear();
                    int idCuisinier = IdCuisinierDepuisMail(maConnection, mailCuisinier);

                    if (idCuisinier == -1)
                    {
                        Console.WriteLine("Erreur : cuisinier non trouvé.");
                        Console.ReadLine();
                        return;
                    }

                    MySqlCommand cmd = maConnection.CreateCommand();
                    cmd.CommandText = "SELECT Id_Commande FROM Commande WHERE Id_Cuisinier = @id AND Statut = 'En préparation'";
                    cmd.Parameters.AddWithValue("@id", idCuisinier);

                    MySqlDataReader reader = cmd.ExecuteReader();
                    List<int> commandes = new List<int>();

                    Console.WriteLine("Commandes en préparation :");
                    while (reader.Read())
                    {
                        int idCommande = reader.GetInt32(0); // Colonne Id_Commande
                        commandes.Add(idCommande);
                        Console.WriteLine($"Commande {idCommande}");
                    }
                    reader.Close();

                    if (commandes.Count == 0)
                    {
                        Console.WriteLine("Aucune commande à livrer.");
                        Console.ReadLine();
                            break;
                    }

                    Console.WriteLine("Entrez l'ID de la commande à livrer :");
                    int idChoisi = Convert.ToInt32(Console.ReadLine());

                    if (!commandes.Contains(idChoisi))
                    {
                        Console.WriteLine("Commande invalide.");
                        Console.ReadLine();
                        return;
                    }

                    AfficherTicketCaisseCommande(maConnection, idChoisi);
                    Console.WriteLine("Souhaitez-vous marquer cette commande comme 'En livraison' ? (oui/non)");
                    string reponse = Console.ReadLine().ToLower();

                    if (reponse == "oui")
                    {
                        MySqlCommand updateCmd = maConnection.CreateCommand();
                        updateCmd.CommandText = "UPDATE Commande SET Statut = 'En livraison' WHERE Id_Commande = @id";
                        updateCmd.Parameters.AddWithValue("@id", idChoisi);
                        updateCmd.ExecuteNonQuery();

                        Console.WriteLine("Commande mise à jour");
                    }
                    else
                    {
                        Console.WriteLine("Aucune modification faite");
                    }
                        choix = "0";
                    }

                else if (choix == "5")
                {

                    Console.Clear();
                    int idCuisinier = IdCuisinierDepuisMail(maConnection, mailCuisinier);

                    if (idCuisinier == -1)
                    {
                        Console.WriteLine("Erreur : cuisinier non trouvé.");
                        Console.ReadLine();
                        return;
                    }

                    MySqlCommand cmd = maConnection.CreateCommand();
                    cmd.CommandText = "SELECT Id_Commande FROM Commande WHERE Id_Cuisinier = @id AND Statut = 'En livraison'";
                    cmd.Parameters.AddWithValue("@id", idCuisinier);

                    MySqlDataReader reader = cmd.ExecuteReader();
                    List<int> commandes = new List<int>();

                    Console.WriteLine("Commandes en livraison :");
                    while (reader.Read())
                    {
                        int idCommande = reader.GetInt32(0); // Colonne Id_Commande
                        commandes.Add(idCommande);
                        Console.WriteLine($"Commande {idCommande}");
                    }
                    reader.Close();

                    if (commandes.Count == 0)
                    {
                        Console.WriteLine("Aucune commande à livrer.");
                        Console.ReadLine();
                            break;
                    }

                    Console.WriteLine("Entrez l'ID de la commande à livrer :");
                    int idChoisi = Convert.ToInt32(Console.ReadLine());

                    if (!commandes.Contains(idChoisi))
                    {
                        Console.WriteLine("Commande invalide.");
                        Console.ReadLine();
                        return;
                    }
                    
                    AfficherTicketCaisseCommande(maConnection, idChoisi);
                    Console.ReadLine() ;

                        #region recup_adresse

                        string s1 = "George V";
                        string s2 = "Saint-Sulpice";
                        // Requête pour récupérer l'adresse du cuisinier
                        MySqlCommand cmdAdresseCuisinier = maConnection.CreateCommand();
                        cmdAdresseCuisinier.CommandText = @"
                        SELECT u.Adresse_postale
                        FROM utilisateur u
                        JOIN Cuisinier c ON u.id_utilisateur = c.id_utilisateur
                        JOIN Commande com ON com.Id_Cuisinier = c.Id_Cuisinier
                        WHERE com.Id_Commande = @idCommande
                        LIMIT 1;";
                        cmdAdresseCuisinier.Parameters.AddWithValue("@idCommande", idChoisi);

                        object resultCuisinier = cmdAdresseCuisinier.ExecuteScalar();
                        if (resultCuisinier != null)
                            s1 = resultCuisinier.ToString();

                        // Requête pour récupérer l'adresse du client
                        MySqlCommand cmdAdresseClient = maConnection.CreateCommand();
                        cmdAdresseClient.CommandText = @"
                        SELECT u.Adresse_postale
                        FROM utilisateur u
                        JOIN Client cl ON u.id_utilisateur = cl.id_utilisateur
                        JOIN Commande com ON com.Id_Client = cl.Id_Client
                        WHERE com.Id_Commande = @idCommande
                        LIMIT 1;";
                        cmdAdresseClient.Parameters.AddWithValue("@idCommande", idChoisi);

                        object resultClient = cmdAdresseClient.ExecuteScalar();
                        if (resultClient != null)
                            s2 = resultClient.ToString();
                        #endregion










                        
                    metrocuisinier(s1, s2);
                    Console.WriteLine("Avez vous livré cette commande ? (oui/non)");
                    string reponse = Console.ReadLine().ToLower();

                    if (reponse == "oui")
                    {
                        MySqlCommand updateCmd = maConnection.CreateCommand();
                        updateCmd.CommandText = "UPDATE Commande SET Statut = 'Livré' WHERE Id_Commande = @id";
                        updateCmd.Parameters.AddWithValue("@id", idChoisi);
                        updateCmd.ExecuteNonQuery();

                        Console.WriteLine("Commande mise à jour");
                    }
                    else
                    {
                        Console.WriteLine("Aucune modification faite");
                    }
                        choix = "0";
                    }

                else if (choix == "6")
                {
                        string s45 = "SELECT a.Titre, a.Commentaire, a.Note, u.Prénom, u.Nom\r\nFROM avis a\r\nJOIN Cuisinier c ON a.Id_Cuisinier = c.Id_Cuisinier\r\nJOIN utilisateur u ON c.id_utilisateur = u.id_utilisateur\r\norder by c.Id_Cuisinier;";
                        AfficherResultatsRequete(maConnection, s45);
                        Console.ReadLine();
                    }

                else if (choix == "7")
                {
                    maConnection.Close();
                    return;
                }
                }
            }
        }
        static void LancerInterfaceAdmin(MySqlConnection maConnection)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("interface Admin ");
                Console.WriteLine("1. voir stat");
                Console.WriteLine("2. suprimer plat");
                Console.WriteLine("3. suprimer utilisateur");
                Console.WriteLine("4. graphe utilisateur");
                Console.WriteLine("5. Quitter");
                string choix = Console.ReadLine();

                if (choix == "1")  // requette
                {
                    Console.Clear();
                    Console.WriteLine("1 pour stat préfaite / 2 pour requette perso");
                    string choixreq = Saisiestring("1", "2");
                    if (choixreq == "1")//préfait
                    {
                        Console.Clear();
                        Console.WriteLine("=== nombre de livraisons effectuées par cuisinier ===");
                        string s100 = "SELECT u.Prénom AS Prenom, u.Nom AS Nom, COUNT(c.Id_Commande) AS Nbr_Livraisons\r\nFROM Cuisinier cu\r\nJOIN  utilisateur u ON cu.id_utilisateur = u.id_utilisateur\r\nLEFT JOIN Commande c ON cu.Id_Cuisinier = c.Id_Cuisinier\r\nGROUP BY cu.Id_Cuisinier, u.Prénom, u.Nom\r\nORDER BY Nbr_Livraisons DESC;";
                        AfficherResultatsRequete(maConnection, s100);
                        Console.WriteLine("\n");

                        Console.WriteLine("=== commande entre 2025-05-01 et 2025-05-014 ===");
                        string s101 = " SELECT c.* FROM Commande c\r\nWHERE  c.Date_commande BETWEEN '2025-05-01' AND '2025-05-014'\r\nORDER BY c.Date_commande;";
                        AfficherResultatsRequete(maConnection, s101);
                        Console.WriteLine("\n");



                        Console.WriteLine("=== prix moyen des commandes === ");
                        string s102 = "select sum(p.prix) / count(cp.Id_Commande) from Commande_Plat cp join commande p;";
                        AfficherResultatsRequete(maConnection, s102);
                        Console.WriteLine("\n");


                        Console.WriteLine("=== moyenne des comptes clients ===");
                        string s103 = "SELECT  AVG(Total_Client) AS Moyenne_Commandes_Par_Client\r\nFROM ( SELECT c.Id_Client, SUM(p.Prix) AS Total_Client\r\n    FROM Commande_Plat cp\r\n    JOIN  Plat p ON cp.Nom_plat = p.Nom_plat\r\n    JOIN  Commande com ON cp.Id_Commande = com.Id_Commande\r\n    JOIN  Client c ON com.Id_Client = c.Id_Client\r\n    GROUP BY c.Id_Client\r\n) AS Total_Par_Client;";
                        AfficherResultatsRequete(maConnection, s103);
                        Console.WriteLine("\n");



                        Console.WriteLine("=== liste des commandes pour un client selon la nationalité des plats, la période === ");
                        string s104 = "SELECT com.Id_Commande as id_co, p.Nom_plat, p.Nationalité,com.Date_commande, p.Prix\r\nFROM  Commande com\r\nJOIN  Commande_Plat cp ON com.Id_Commande = cp.Id_Commande\r\nJOIN  Plat p ON cp.Nom_plat = p.Nom_plat\r\nWHERE  com.Id_Client = 100006  -- Remplacer par l’ID du client recherché\r\nAND com.Date_commande BETWEEN '2025-05-01' AND '2025-05-10'\r\n    \r\nORDER BY com.Date_commande, p.Nationalité, p.Nom_plat;";
                        AfficherResultatsRequete(maConnection, s104);
                        Console.WriteLine("\n");





                        Console.WriteLine("=== nombre d'utilisateur === ");
                        string s1 = "SELECT count(*) FROM utilisateur;";
                        AfficherResultatsRequete(maConnection, s1);
                        Console.WriteLine("\n");

                        Console.WriteLine("=== nombre de client ===  ");
                        string s2 = "SELECT count(*) FROM Client;";
                        AfficherResultatsRequete(maConnection, s2);
                        Console.WriteLine("\n");

                        Console.WriteLine("=== utilisateur avec mot de passe faible ===  ");
                        string s3 = "select u.Prénom ,u.nom ,char_length(Mot_de_passe) as nombre_de_caractère from utilisateur u \r\norder by char_length(Mot_de_passe) asc\r\nlimit 1;";
                        AfficherResultatsRequete(maConnection, s3);
                        Console.WriteLine("\n");

                        Console.WriteLine("=== la plus grosse dépense ===  ");
                        string s4 = "SELECT u.Prénom, u.Nom, SUM(c.Prix) AS Total_Dépensé\r\nFROM utilisateur u\r\nJOIN Client cl ON u.id_utilisateur = cl.id_utilisateur\r\nJOIN Commande c ON cl.Id_Client = c.Id_Client\r\nGROUP BY u.Prénom, u.Nom\r\nORDER BY Total_Dépensé DESC\r\nLIMIT 1;";
                        AfficherResultatsRequete(maConnection, s4);
                        Console.WriteLine("\n");

                        Console.WriteLine("=== Le cuisinier ayant reçu la meilleure note moyenne ===  ");
                        string s5 = "SELECT u.Prénom, u.Nom, AVG(a.Note) AS Moyenne_Note\r\nFROM avis a\r\nJOIN Cuisinier cu ON a.Id_Cuisinier = cu.Id_Cuisinier\r\nJOIN utilisateur u ON cu.id_utilisateur = u.id_utilisateur\r\nGROUP BY u.Prénom, u.Nom\r\nORDER BY Moyenne_Note DESC\r\nLIMIT 1;\r\n";
                        AfficherResultatsRequete(maConnection, s5);
                        Console.WriteLine("\n");

                        Console.WriteLine("=== Le plat le plus commandé ===  ");
                        string s6 = "SELECT    cp.Nom_plat, COUNT(*) AS Nombre_Commandes\r\nFROM  Commande_Plat cp\r\nGROUP BY  cp.Nom_plat\r\nORDER BY  Nombre_Commandes DESC\r\nLIMIT 1;";
                        AfficherResultatsRequete(maConnection, s6);
                        Console.WriteLine("\n");

                        Console.WriteLine("===  Le client ayant passé le plus de commandes ===  ");
                        string s7 = "SELECT u.Prénom, u.Nom, COUNT(c.Id_Commande) AS Nombre_Commandes\r\nFROM utilisateur u\r\nJOIN Client cl ON u.id_utilisateur = cl.id_utilisateur\r\nJOIN Commande c ON cl.Id_Client = c.Id_Client\r\nGROUP BY u.Prénom, u.Nom\r\nORDER BY Nombre_Commandes DESC\r\nLIMIT 1;\r\n";
                        AfficherResultatsRequete(maConnection, s7);
                        Console.WriteLine("\n");

                        Console.WriteLine(" === Le plat le plus cher === ");
                        string s8 = "SELECT Nom_plat, Prix\r\nFROM Plat\r\nORDER BY Prix DESC\r\nLIMIT 1;\r\n";
                        AfficherResultatsRequete(maConnection, s8);
                        Console.WriteLine("\n");



                        Console.ReadLine();
                    }
                    else if (choixreq == "2")//perso
                    {
                        Console.WriteLine("entrez votre requette : ");
                        string s0 = Console.ReadLine();
                        AfficherResultatsRequete(maConnection, s0);
                        Console.ReadLine();
                    }


                } // stat

                else if (choix == "2")
                {
                    Console.Clear();
                    Afficherplat2(maConnection);
                    Console.WriteLine("Souhaitez-vous supprimer un plat ? (oui/non)");
                    string verif = Saisiestring("oui", "non");

                    if (verif == "oui")
                    {
                        nuc(maConnection);
                        Console.WriteLine("Votre plat a été supprimé.");
                    }
                    else
                    {
                        Console.WriteLine("Souhaitez-vous afficher les ingrédients d'un plat ? (oui/non)");
                        string verif2 = Saisiestring("oui", "non");

                        if (verif2 == "oui")
                        {
                            Console.Clear();
                            Afficherplat2(maConnection);
                            Console.WriteLine("Sélectionner un plat :");
                            string platchoisi = Console.ReadLine();
                            Afficher_Ingrédient(maConnection, platchoisi);
                            Console.ReadLine();
                        }
                    }
                }  // suprimer plat

                else if (choix == "3")
                {
                    Console.WriteLine("mettre id_utilisateur a supprimer");
                    int idUtilisateur = Convert.ToInt32(Console.ReadLine());

                    try
                    {
                        // Commencer une transaction pour garantir la cohérence
                        using var transaction = maConnection.BeginTransaction();

                        // Étape 1 : Supprimer les avis
                        var cmdAvis = new MySqlCommand(
                            "DELETE FROM avis WHERE Id_Client IN (SELECT Id_Client FROM Client WHERE id_utilisateur = @idU) " +
                            "OR Id_Cuisinier IN (SELECT Id_Cuisinier FROM Cuisinier WHERE id_utilisateur = @idU)", maConnection, transaction);
                        cmdAvis.Parameters.AddWithValue("@idU", idUtilisateur);
                        cmdAvis.ExecuteNonQuery();

                        // Étape 2 : Supprimer Commande_Plat
                        var cmdCmdPlat = new MySqlCommand(
                            "DELETE FROM Commande_Plat WHERE Id_Commande IN (SELECT Id_Commande FROM Commande WHERE Id_Client IN " +
                            "(SELECT Id_Client FROM Client WHERE id_utilisateur = @idU) OR Id_Cuisinier IN " +
                            "(SELECT Id_Cuisinier FROM Cuisinier WHERE id_utilisateur = @idU))", maConnection, transaction);
                        cmdCmdPlat.Parameters.AddWithValue("@idU", idUtilisateur);
                        cmdCmdPlat.ExecuteNonQuery();

                        // Étape 3 : Supprimer les Commandes
                        var cmdCommande = new MySqlCommand(
                            "DELETE FROM Commande WHERE Id_Client IN (SELECT Id_Client FROM Client WHERE id_utilisateur = @idU) " +
                            "OR Id_Cuisinier IN (SELECT Id_Cuisinier FROM Cuisinier WHERE id_utilisateur = @idU)", maConnection, transaction);
                        cmdCommande.Parameters.AddWithValue("@idU", idUtilisateur);
                        cmdCommande.ExecuteNonQuery();

                        // Étape 4 : Supprimer les plats du cuisinier s'il existe
                        var cmdPlat = new MySqlCommand(
                            "DELETE FROM Plat WHERE Id_Cuisinier IN (SELECT Id_Cuisinier FROM Cuisinier WHERE id_utilisateur = @idU)", maConnection, transaction);
                        cmdPlat.Parameters.AddWithValue("@idU", idUtilisateur);
                        cmdPlat.ExecuteNonQuery();

                        // Étape 5 : Supprimer les entrées dans Cuisinier et Client
                        var cmdCuisinier = new MySqlCommand("DELETE FROM Cuisinier WHERE id_utilisateur = @idU", maConnection, transaction);
                        cmdCuisinier.Parameters.AddWithValue("@idU", idUtilisateur);
                        cmdCuisinier.ExecuteNonQuery();

                        var cmdClient = new MySqlCommand("DELETE FROM Client WHERE id_utilisateur = @idU", maConnection, transaction);
                        cmdClient.Parameters.AddWithValue("@idU", idUtilisateur);
                        cmdClient.ExecuteNonQuery();

                        // Étape 6 : Supprimer l'utilisateur
                        var cmdUtilisateur = new MySqlCommand("DELETE FROM utilisateur WHERE id_utilisateur = @idU", maConnection, transaction);
                        cmdUtilisateur.Parameters.AddWithValue("@idU", idUtilisateur);
                        cmdUtilisateur.ExecuteNonQuery();

                        // Validation de la transaction
                        transaction.Commit();

                        Console.WriteLine($"Utilisateur {idUtilisateur} supprimé avec succès.");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Erreur lors de la suppression : " + ex.Message);
                    }
                } // suprimer utilisateur

                
                else if (choix == "4")
                {
                    coloration();
                }


                else if (choix == "5")
                {
                    maConnection.Close();
                    return;
                }
            }


        }


        public static void AfficherResultatsRequete(MySqlConnection maConnection, string requete)
        {
            try
            {
                // Créer la commande SQL
                MySqlCommand command = maConnection.CreateCommand();
                command.CommandText = requete;

                // Exécuter la commande et obtenir un DataReader
                MySqlDataReader reader = command.ExecuteReader();

                // Vérifier si des résultats sont présents
                if (reader.HasRows)
                {
                    // Afficher les noms des colonnes
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        Console.Write(reader.GetName(i) + "\t");
                    }
                    Console.WriteLine();

                    // Afficher les valeurs des colonnes pour chaque ligne
                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            Console.Write(reader.GetValue(i) + "\t");
                        }
                        Console.WriteLine();
                    }
                }
                else
                {
                    Console.WriteLine("Aucun résultat trouvé.");
                }

                reader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur lors de l'exécution de la requête : " + ex.Message);
            }
        }

        public static string Afficher_mdp_de_mail(MySqlConnection maConnection, string requete)
        {
            string resultat = null;

            try
            {
                // Créer la commande SQL
                MySqlCommand command = maConnection.CreateCommand();
                command.CommandText = requete;

                // Exécuter la commande et obtenir un DataReader
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    // Vérifier si des résultats sont présents
                    if (reader.HasRows)
                    {
                        // Lire la première ligne (dans le cas où il n'y a qu'un seul résultat)
                        if (reader.Read())
                        {
                            // Récupérer la première valeur de la ligne (index 0)
                            resultat = reader.GetValue(0).ToString();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Aucun résultat trouvé.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur lors de l'exécution de la requête : " + ex.Message);
            }

            return resultat;
        }


        static string AfficherPlats(MySqlConnection maConnection)
        {
            string platChoisi = "";
            List<string> listePlats = new List<string>();

            string requete = @"
                SELECT 
                Nom_plat, 
                Prix, 
                Nationalité, 
                utilisateur.Nom AS Nom_Cuisinier, 
                (SELECT AVG(Note) FROM avis WHERE avis.Id_Cuisinier = Cuisinier.Id_Cuisinier) AS Note_Cuisinier,
                Nbr_part
                FROM Cuisinier
                JOIN utilisateur ON Cuisinier.id_utilisateur = utilisateur.id_utilisateur
                JOIN Plat ON Plat.Id_Cuisinier = Cuisinier.Id_Cuisinier;
                ";

            MySqlCommand commande = new MySqlCommand(requete, maConnection);
            MySqlDataReader reader = commande.ExecuteReader();

            Console.WriteLine("Voici les plats disponibles :\n");

            while (reader.Read())
            {
                string nomPlat = reader["Nom_plat"].ToString();
                string prix = reader["Prix"].ToString();
                string nationalite = reader["Nationalité"].ToString();
                string nomCuisinier = reader["Nom_Cuisinier"].ToString();
                string note = reader["Note_Cuisinier"].ToString();
                string nbrPart = reader["Nbr_part"].ToString();

                // On n'affiche pas les plats sans parts disponibles
                // if (Convert.ToInt32(nbrPart) <= 0) continue;

                listePlats.Add(nomPlat);

                Console.WriteLine($"- {nomPlat}");
                Console.WriteLine($"  Prix : {prix}euro");
                Console.WriteLine($"  Nationalité : {nationalite}");
                Console.WriteLine($"  Cuisinier : {nomCuisinier}");
                Console.WriteLine($"  Note moyenne : {note}");
                Console.WriteLine($"  Parts disponibles : {nbrPart}\n");
            }

            reader.Close();

            // Demande à l'utilisateur de choisir un plat
            Console.WriteLine("Quel plat voulez-vous ?");
            bool platValide = false;

            while (!platValide)
            {
                Console.Write("Nom du plat : ");
                platChoisi = Console.ReadLine();

                if (listePlats.Contains(platChoisi))
                {
                    platValide = true;
                }
                else
                {
                    Console.WriteLine("Ce plat n'existe pas ou n'a plus de parts, réessayez.");
                }
            }

            return platChoisi;
        }

        static string AfficherPlatsducuisiner(MySqlConnection conn, int? idCuisinier = null)
        {
            List<string> plats = new List<string>();
            string requete = @"
                SELECT 
                Plat.Nom_plat, 
                Plat.Prix, 
                Plat.Nationalité, 
                utilisateur.Nom AS Nom_Cuisinier, 
                (SELECT AVG(avis.Note) FROM avis WHERE avis.Id_Cuisinier = Cuisinier.Id_Cuisinier) AS Note_Cuisinier,
                Plat.Nbr_part
                FROM Cuisinier
                JOIN utilisateur ON Cuisinier.id_utilisateur = utilisateur.id_utilisateur
                JOIN Plat ON Plat.Id_Cuisinier = Cuisinier.Id_Cuisinier
                WHERE Plat.Id_Cuisinier = @idCuisinier
                GROUP BY Plat.Nom_plat, Plat.Nbr_part, Plat.Nationalité
                ORDER BY Plat.Nom_plat;
                ";

            MySqlCommand cmd = new MySqlCommand(requete, conn);

            if (idCuisinier.HasValue)
            {
                cmd.Parameters.AddWithValue("@idCuisinier", idCuisinier.Value);
            }

            MySqlDataReader reader = cmd.ExecuteReader();

            int numero = 1;
            while (reader.Read())
            {
                string nomPlat = reader["Nom_plat"].ToString();
                int nbPart = Convert.ToInt32(reader["Nbr_part"]);
                string Nationalité = reader["Nationalité"].ToString();
                double moyenneNote = Convert.ToDouble(reader["Note_Cuisinier"]);


                if (nbPart <= 0)
                    continue;

                plats.Add(nomPlat);

                Console.WriteLine($"{numero}. {nomPlat} - {nbPart} parts | Nationalité : {Nationalité} | Note : {moyenneNote:F1}/5");
                numero++;
            }

            reader.Close();

            if (plats.Count == 0)
            {
                Console.WriteLine("Aucun plat trouvé avec des parts disponibles.");
                return null;
            }

            Console.WriteLine("Entrez le numéro du plat choisi :");
            string saisie = Console.ReadLine();

            if (int.TryParse(saisie, out int choix))
            {
                if (choix > 0 && choix <= plats.Count)
                {
                    return plats[choix - 1];
                }
            }
            Console.WriteLine("Choix invalide.");
            return null;
        }

        static void Afficher_Ingrédient(MySqlConnection maConnection, string platchoisi)
        {
            try
            {
                MySqlCommand command = maConnection.CreateCommand();
                command.CommandText = $"SELECT \r\n    i.Nom AS Nom_ingredient,\r\n    i.Origine,\r\n    i.Régime_alimentaire,\r\n    i.certification\r\nFROM \r\n    Plat_Ingredient pi\r\nJOIN \r\n    Ingrédient i ON pi.Nom_ingredient = i.Nom\r\nWHERE \r\n    pi.Nom_plat = '{platchoisi}';";

                using MySqlDataReader reader = command.ExecuteReader();
                Console.WriteLine("\ninggrédient du plat :");

                string[] valuestring = new string[reader.FieldCount];
                while (reader.Read())
                {
                    valuestring[0] = reader.GetValue(0).ToString();
                    Console.WriteLine(valuestring[0] + ":");
                    for (int i = 1; i < reader.FieldCount; i++)
                    {
                        valuestring[i] = reader.GetValue(i).ToString();
                        Console.Write(valuestring[i] + "\t\t");
                    }
                    Console.WriteLine();
                    Console.WriteLine();
                }





            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur : " + ex.Message);
            }
        }

        static void Afficher_avis_du_plat_du_cuisinier(MySqlConnection maConnection, string platchoisi)
        {
            try
            {
                MySqlCommand command = maConnection.CreateCommand();
                command.CommandText = $"SELECT u.Prénom,u.Nom,a.Note,a.Titre,a.Commentaire FROM Plat p JOIN    Cuisinier c ON p.Id_Cuisinier = c.Id_Cuisinier\r\nJOIN \r\n    avis a ON a.Id_Cuisinier = c.Id_Cuisinier\r\nJOIN \r\n    Client cl ON a.Id_Client = cl.Id_Client\r\nJOIN \r\n    utilisateur u ON cl.id_utilisateur = u.id_utilisateur\r\nWHERE \r\n    p.Nom_plat = '{platchoisi}';";

                using MySqlDataReader reader = command.ExecuteReader();
                Console.WriteLine("\nAvis du Cuisinier:");

                string[] valuestring = new string[reader.FieldCount];
                while (reader.Read())
                {
                    valuestring[0] = reader.GetValue(0).ToString();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        string s0 = "";
                        string s1 = "";
                        if (i == 0) { s0 = " "; }
                        if (i == 1) { s0 = " "; }
                        if (i == 2) { s0 = "/5"; }
                        if (i == 3) { s1 = "\n"; }
                        if (i == 4) { s1 = ", "; }


                        valuestring[i] = reader.GetValue(i).ToString();
                        Console.Write(s1 + valuestring[i] + s0);

                    }
                    Console.WriteLine();
                    Console.WriteLine();
                }





            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur : " + ex.Message);
            }
        }


        static int IdCuisinierDepuisMail(MySqlConnection maConnection, string mail)
        {
            int idCuisinier = -1;

            MySqlCommand cmd = maConnection.CreateCommand();
            cmd.CommandText = "SELECT c.Id_Cuisinier FROM utilisateur u JOIN cuisinier c ON c.id_utilisateur = u.id_utilisateur WHERE u.Mail = @mail";
            cmd.Parameters.AddWithValue("@mail", mail);

            MySqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                idCuisinier = reader.GetInt32(0); // Récupère le premier champ de la ligne
            }

            reader.Close();
            return idCuisinier;
        }


        /// <summary>
        /// insertion dans BDD de la commande_plats
        /// </summary>
        /// <param name="contenuListe"></param>
        static void ticketdecaisse(MySqlConnection maConnection, int idClient, int idCuisinier, List<(string NomPlat, int NbParts, string AdresseLivraison)> panier, int prixTotal)
        {
            Random ran = new Random();

            // Vérifier si l'idClient existe dans la table Client
            var verifClient = new MySqlCommand("SELECT COUNT(*) FROM Client WHERE Id_Client = @idClient", maConnection);
            verifClient.Parameters.AddWithValue("@idClient", idClient);
            int clientCount = Convert.ToInt32(verifClient.ExecuteScalar());

            if (clientCount == 0)
            {
                Console.WriteLine($"Erreur : Le client avec id {idClient} n'existe pas.");
                return;  // Arrêter l'exécution si le client n'existe pas
            }

            // Insérer la commande dans la base de données sans spécifier l'ID
            var date_ajd = DateTime.Now;
            var insertCommande = new MySqlCommand(@"
        INSERT INTO Commande (Date_commande, Prix, Temps, Statut, Id_Cuisinier, Id_Client)
        VALUES (@date, @prix, @temps, 'En préparation', @cuisinier, @client)", maConnection);

            insertCommande.Parameters.AddWithValue("@date", date_ajd);
            insertCommande.Parameters.AddWithValue("@prix", prixTotal);
            insertCommande.Parameters.AddWithValue("@temps", date_ajd.AddMinutes(30));
            insertCommande.Parameters.AddWithValue("@cuisinier", idCuisinier);
            insertCommande.Parameters.AddWithValue("@client", idClient);

            insertCommande.ExecuteNonQuery();

            // Récupérer l'ID de la commande généré automatiquement
            var getLastInsertIdCmd = new MySqlCommand("SELECT LAST_INSERT_ID()", maConnection);
            int idCommande = Convert.ToInt32(getLastInsertIdCmd.ExecuteScalar());

            // Insertion des plats dans la table Commande_Plat
            foreach (var plat in panier)
            {
                string nomPlat = plat.NomPlat;
                int nbPart = plat.NbParts;
                string adresseLiv = plat.AdresseLivraison;

                // Verif pour éviter les doublons
                var verifPlat = new MySqlCommand("SELECT COUNT(*) FROM Commande_Plat WHERE Id_Commande = @Id_Commande AND Nom_plat = @Nom_plat", maConnection);
                verifPlat.Parameters.AddWithValue("@Id_Commande", idCommande);
                verifPlat.Parameters.AddWithValue("@Nom_plat", nomPlat);
                int platCount = Convert.ToInt32(verifPlat.ExecuteScalar());

                // Si plat pas déjà dans commande, l'ajoute
                if (platCount == 0)
                {
                    for (int i = 0; i < nbPart; i++)
                    {
                        var insertPlat = new MySqlCommand("INSERT IGNORE INTO Commande_Plat (Id_Commande, Nom_plat, adresse_liv) " +
                            "VALUES (@Id_Commande, @Nom_plat, @adresse_liv)", maConnection);
                        insertPlat.Parameters.AddWithValue("@Id_Commande", idCommande);
                        insertPlat.Parameters.AddWithValue("@Nom_plat", nomPlat);
                        insertPlat.Parameters.AddWithValue("@adresse_liv", adresseLiv);
                        insertPlat.ExecuteNonQuery();
                    }
                }
                else
                {
                    Console.WriteLine($"Le plat '{nomPlat}' est déjà présent dans la commande {idCommande}. Aucune insertion effectuée.");
                }
            }
            Console.Clear();
            Console.WriteLine("\n=== TICKET DE CAISSE ===");
            Console.WriteLine($"Commande ID: {idCommande}");
            Console.WriteLine($"Client ID: {idClient}");
            Console.WriteLine($"Cuisinier ID: {idCuisinier}");
            Console.WriteLine($"Date de commande: {DateTime.Now}");
            Console.WriteLine("Plats commandés :");

            foreach (var plat in panier)
            {
                Console.WriteLine($"- {plat.NomPlat} (x{plat.NbParts}) - Adresse de livraison : {plat.AdresseLivraison}");
            }

            Console.WriteLine($"Prix total: {prixTotal} euros");
            Console.WriteLine("===========================");
        }
        /// <summary>
        /// saisi sécurisé entre 2 string
        /// </summary>
        static string Saisiestring(string x, string y)
        {
            string val = "";
            while (true)
            {
                string st = Console.ReadLine();   // string a tester

                if (st == x || st == y) // si c'est dans l'interval 
                {
                    val = st;
                    break;
                }
                else
                {
                    Console.WriteLine($"il faut que ce sois {x} ou {y} ");
                }
            }
            return val;
        }

        /// <summary>
        /// permet d'autoriser des nombre entier dans un interval
        /// </summary>
        static int Saisieval(int x, int y)
        {
            int val;
            while (true)
            {
                string st = Console.ReadLine();

                try
                {
                    val = Convert.ToInt32(st);
                    if (val >= x && val <= y) // si c'est dans l'interval 
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine($"Nombre entre {x} et {y}");
                    }
                }
                catch
                {
                    Console.WriteLine($"numéro entre {x} et {y}");
                }
            }
            return val;
        }


        /// <summary>
        /// Permet au cuisinier d'ajouter un plat
        /// </summary>
        /// <param name="maConnection"></param>
        /// <param name="Id_Cuisinier"></param>
        static void Ajoutplat(MySqlConnection maConnection, string Id_Cuisinier)
        {
            Console.WriteLine("Nom du plat :");
            string nouvplat = Console.ReadLine();

            Console.WriteLine("Prix du plat :");
            string prix = Console.ReadLine(); //faire une saisie sec

            Console.WriteLine("Nationalité du plat :");
            string Nat = Console.ReadLine();

            MySqlCommand command = maConnection.CreateCommand();
            command.CommandText = @"INSERT INTO Plat (Nom_plat, Prix, Nationalité, Id_Cuisinier) VALUE (@Nom_plat,@Prix,@Nationalité,@Id_Cuisinier);";
            command.Parameters.AddWithValue("@Nom_plat", nouvplat);
            command.Parameters.AddWithValue("@Prix", prix);
            command.Parameters.AddWithValue("@Nationalité", Nat);
            command.Parameters.AddWithValue("@Id_Cuisinier", Id_Cuisinier);

            command.ExecuteNonQuery();
            Console.WriteLine($"Le plat : {nouvplat} a été ajouté");
        }

        /// <summary>
        /// permet de suprimer un plat
        /// </summary>
        /// <param name="maConnection"></param>
        static void nuc(MySqlConnection maConnection)
        {
            Console.WriteLine("Quelle plat souhaitez vous supprimer");
            string platsupp = Console.ReadLine();
            MySqlCommand command = maConnection.CreateCommand();
            command.CommandText = @"DELETE FROM Plat_Ingredient WHERE Nom_plat = @Nom";
            command.Parameters.AddWithValue("@Nom", platsupp);
            command.ExecuteNonQuery();


            MySqlCommand deletecommand = maConnection.CreateCommand();
            deletecommand.CommandText = @"DELETE FROM Plat WHERE Nom_plat = @Nom";
            deletecommand.Parameters.AddWithValue("@Nom", platsupp);
            deletecommand.ExecuteNonQuery();

        }

        static int PrixDuPlat(MySqlConnection maConnection, string nomPlat, int idCuisinier)
        {
            var cmd = new MySqlCommand("SELECT Prix FROM Plat WHERE Nom_plat = @NomPlat AND Id_Cuisinier = @IdCuisinier", maConnection);
            cmd.Parameters.AddWithValue("@NomPlat", nomPlat);
            cmd.Parameters.AddWithValue("@IdCuisinier", idCuisinier);

            // Exécution de la commande et récupération du prix
            object result = cmd.ExecuteScalar();

            if (result == null)
            {
                // Si le plat n'existe pas ou si la requête échoue, on renvoie 0 comme prix
                Console.WriteLine($"Erreur : Le plat '{nomPlat}' n'a pas été trouvé pour le cuisinier {idCuisinier}.");
                return 0;
            }

            // Retourner le prix du plat
            return Convert.ToInt32(result);
        }

        static void AjoutIngredient(MySqlConnection maConnection, string platchoisi)
        {
            while (true)
            {
                Console.WriteLine("Nom de l'ingredient à ajouter :\nou 'Quitter' pout terminer");

                string nomIngr = Console.ReadLine();
                if (nomIngr == "Quitter")
                {
                    break;
                }
                Console.WriteLine("Origine de l'ingredient :");
                string origine = Console.ReadLine();
                Console.WriteLine("Régime alimentaire (halal, vegan, ect) :");
                string regimeali = Console.ReadLine();
                Console.WriteLine("La certification (AOP, bio, ect) :");
                string certif = Console.ReadLine();

                MySqlCommand checkCommand = maConnection.CreateCommand();
                checkCommand.CommandText = "SELECT COUNT(*) FROM `Ingrédient` WHERE Nom = @Nom";
                checkCommand.Parameters.AddWithValue("@Nom", nomIngr);

                int count = Convert.ToInt32(checkCommand.ExecuteScalar());

                if (count == 0)
                {

                    MySqlCommand command = maConnection.CreateCommand();
                    command.CommandText = @"INSERT INTO Ingrédient  (Nom, Origine, Régime_alimentaire, Certification) VALUE (@Nom,@Origine,@Régime_alimentaire,@Certification);";
                    command.Parameters.AddWithValue("@Nom", nomIngr);
                    command.Parameters.AddWithValue("@Origine", origine);
                    command.Parameters.AddWithValue("@Régime_alimentaire", regimeali);
                    command.Parameters.AddWithValue("@Certification", certif);

                    command.ExecuteNonQuery();
                }
                MySqlCommand linkcommand = maConnection.CreateCommand();
                linkcommand.CommandText = @"INSERT INTO Plat_Ingredient (Nom_plat, Nom_ingredient) VALUE (@Nom_plat,@Nom_ingredient);";
                linkcommand.Parameters.AddWithValue("@Nom_plat", platchoisi);
                linkcommand.Parameters.AddWithValue("@Nom_ingredient", nomIngr);
                linkcommand.ExecuteNonQuery();

                Console.WriteLine($"l'ingredient {nomIngr} a été ajoute au plat {platchoisi}");
            }
        }

        /// <summary>
        /// affiche les plat du point de vu du cuisinier
        /// </summary>
        /// <param name="maConnection"></param>
        static void Afficherplat2(MySqlConnection maConnection)
        {
            MySqlCommand command = maConnection.CreateCommand();
            command.CommandText = "SELECT \r\n    Nom_plat, \r\n    Prix, \r\n    Nationalité, \r\n    Nom AS Nom_Cuisinier, \r\n    (SELECT AVG(Note) \r\n     FROM avis \r\n     WHERE avis.Id_Cuisinier = Cuisinier.Id_Cuisinier) AS Note_Cuisinier\r\nFROM Cuisinier\r\nJOIN utilisateur ON Cuisinier.id_utilisateur = utilisateur.id_utilisateur\r\nJOIN Plat ON Plat.Id_Cuisinier = Cuisinier.Id_Cuisinier;";

            using MySqlDataReader reader = command.ExecuteReader();
            Console.WriteLine("\nListe des plats :");

            string[] valuestring = new string[reader.FieldCount];
            List<string> platsDisponibles = new List<string>();// pour liste verif
            while (reader.Read())
            {

                valuestring[0] = reader.GetValue(0).ToString();
                platsDisponibles.Add(valuestring[0]); // pour liste verif
                Console.WriteLine(valuestring[0] + ":");
                for (int i = 1; i < reader.FieldCount; i++)
                {
                    string s0 = "";
                    string s1 = "";
                    if (i == 1) { s0 = " euros"; }
                    if (i == 2) { s1 = "nationalité "; }
                    if (i == 3) { s1 = "cuisinier : "; }
                    if (i == 4) { s1 = "note : "; }

                    valuestring[i] = reader.GetValue(i).ToString();
                    Console.Write(s1 + valuestring[i] + s0 + "\t\t");

                }
                Console.WriteLine();
                Console.WriteLine();
            }
        }

        static int IDclientdepuismail(MySqlConnection maConnection, string mail)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT id_utilisateur FROM utilisateur WHERE Mail = @Mail", maConnection);
            cmd.Parameters.AddWithValue("@Mail", mail);

            object result = cmd.ExecuteScalar();
            if (result != null)
            {
                int id = Convert.ToInt32(result);
                Console.WriteLine($"Utilisateur trouvé : ID = {id}");
                return id;

            }
            else
            {
                Console.WriteLine("Erreur : client introuvable avec ce mail.");
                return -1;
            }
        }
        static int IDcuisinierdepuisplat(MySqlConnection maConnection, string platChoisi)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT Id_Cuisinier FROM Plat WHERE Nom_plat = @Nom_plat", maConnection);
            cmd.Parameters.AddWithValue("@Nom_plat", platChoisi);

            object result = cmd.ExecuteScalar();
            if (result != null)
            {
                return Convert.ToInt32(result);
            }
            else
            {
                Console.WriteLine("Erreur : Cuisinier introuvable avec ce nom.");
                return -1;
            }
        }

        static void AfficherTicketCaisseCommande(MySqlConnection maConnection, int idCommande)
        {
            // Infos de base
            MySqlCommand cmfinfo = maConnection.CreateCommand();
            cmfinfo.CommandText = @"SELECT Date_commande, Prix, Temps, Statut FROM Commande WHERE Id_Commande = @id";
            cmfinfo.Parameters.AddWithValue("@id", idCommande);

            MySqlDataReader reader = cmfinfo.ExecuteReader();
            if (reader.Read())
            {
                Console.WriteLine("\n=== TICKET DE COMMANDE ===");
                Console.WriteLine($"Commande ID : {idCommande}");
                Console.WriteLine($"Date        : {reader.GetDateTime(0)}");
                Console.WriteLine($"Prix total  : {reader.GetInt32(1)} euro");
                Console.WriteLine($"Heure estimée : {reader.GetDateTime(2)}");
                Console.WriteLine($"Statut      : {reader.GetString(3)}");
            }
            reader.Close();

            // Plats de la commande
            MySqlCommand cmdplats = maConnection.CreateCommand();
            cmdplats.CommandText = @"SELECT Nom_plat, adresse_liv FROM Commande_Plat WHERE Id_Commande = @id";
            cmdplats.Parameters.AddWithValue("@id", idCommande);

            MySqlDataReader readerPlats = cmdplats.ExecuteReader();
            Console.WriteLine("Plats commandés :");
            while (readerPlats.Read())
            {
                string nomPlat = readerPlats.GetString(0);
                string adresse = readerPlats.GetString(1);
                Console.WriteLine($"- {nomPlat} livré à : {adresse}");
            }
            readerPlats.Close();
            Console.WriteLine("===========================");
        }
    }
}




/*
Program.cs	        Point d’entrée Main()
FenetreGraphe.cs	Interface graphique
Station.cs	        Station et StationTemp
Lien.cs	            Lien et dessin des liaisons
Algorithmes.cs	    Dijkstra et Bellman-Ford
Donnees.cs	        Chargement des fichiers
Dessinateur.cs	    Méthodes DessinerCarte() et ConvertirCoord()

*/