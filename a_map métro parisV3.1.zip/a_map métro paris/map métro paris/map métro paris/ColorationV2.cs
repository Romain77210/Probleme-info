﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace GrapheApp
{
    public partial class ColorationV2 : Form
    {
        private List<string> sommets = new List<string>();

        private List<Tuple<string, string>> arretes = new List<Tuple<string, string>>();

        private List<int> couleurs = new List<int>();

        private List<Color> palette = new List<Color>
        {
            Color.Red, Color.Green, Color.Blue, Color.Yellow, Color.Orange,
            Color.Purple, Color.Brown, Color.Pink, Color.Cyan, Color.Magenta,
            Color.Lime, Color.Teal, Color.Olive, Color.Maroon, Color.Navy,
            Color.Gray, Color.Gold, Color.Turquoise, Color.Violet, Color.Salmon
        };

        public ColorationV2()
        {
            InitializeComposant();

            ChargerDonneesDepuisMySQL();

            ConstruireListeSommets();

            AppliquerColoration();

            this.Paint += Coloration_Paint;
        }

        /// <summary>
        /// Charge les données de la base MySQL : 
        /// - Tous les clients et cuisiniers reliés par des commandes.
        /// - Chaque commande devient une arête du graphe.
        /// </summary>
        private void ChargerDonneesDepuisMySQL()
        {
            string connStr = "server=localhost;user=root;password=root;database=Projet";

            using (var conn = new MySqlConnection(connStr))
            {
                conn.Open();

                string query = @"
                    SELECT DISTINCT Id_Client, Id_Cuisinier
                    FROM Commande";

                using (var cmd = new MySqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string client = "U" + reader.GetInt32(0);
                        string cuisinier = "C" + reader.GetInt32(1);
                        arretes.Add(new Tuple<string, string>(client, cuisinier));
                    }
                }
            }
        }

        /// <summary>
        /// Construit la liste unique des sommets à partir des arêtes.
        /// Initialise la couleur de chaque sommet à -1 (non colorié).
        /// </summary>
        private void ConstruireListeSommets()
        {
            foreach (var arrete in arretes)
            {
                if (!sommets.Contains(arrete.Item1))
                    sommets.Add(arrete.Item1);

                if (!sommets.Contains(arrete.Item2))
                    sommets.Add(arrete.Item2);
            }

            for (int i = 0; i < sommets.Count; i++)
                couleurs.Add(-1);
        }

        /// <summary>
        /// Applique un algorithme glouton pour colorier le graphe :
        /// chaque sommet prend la plus petite couleur non utilisée par ses voisins.
        /// </summary>
        private void AppliquerColoration()
        {
            for (int i = 0; i < sommets.Count; i++)
            {
                string sommet = sommets[i];
                HashSet<int> couleursVoisins = new HashSet<int>();

                foreach (var arrete in arretes)
                {
                    string voisin = null;

                    if (arrete.Item1 == sommet)
                        voisin = arrete.Item2;
                    else if (arrete.Item2 == sommet)
                        voisin = arrete.Item1;

                    if (voisin != null)
                    {
                        int indexVoisin = sommets.IndexOf(voisin);
                        int couleurVoisin = couleurs[indexVoisin];
                        if (couleurVoisin != -1)
                            couleursVoisins.Add(couleurVoisin);
                    }
                }

                int couleur = 0;
                while (couleursVoisins.Contains(couleur))
                    couleur++;

                couleurs[i] = couleur;
            }
        }

        /// <summary>
        /// Dessine le graphe sur le formulaire.
        /// Les clients sont positionnés en haut, les cuisiniers en bas.
        /// Les sommets sont coloriés selon l'algorithme appliqué.
        /// </summary>
        private void Coloration_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            int largeur = this.ClientSize.Width;
            int hauteur = this.ClientSize.Height;


            Dictionary<string, Point> positions = new Dictionary<string, Point>();

            int nbClients = sommets.Count(s => s.StartsWith("U"));
            int nbCuisiniers = sommets.Count(s => s.StartsWith("C"));

            int rayon = 30;


            int espaceClient = nbClients > 0 ? largeur / (nbClients + 1) : largeur;
            int espaceCuisinier = nbCuisiniers > 0 ? largeur / (nbCuisiniers + 1) : largeur;

            int clientPos = 1;
            int cuisinierPos = 1;


            foreach (var sommet in sommets)
            {
                Point pos;

                if (sommet.StartsWith("U"))
                {
                    pos = new Point(espaceClient * clientPos, 100); // Clients en haut
                    clientPos++;
                }
                else
                {
                    pos = new Point(espaceCuisinier * cuisinierPos, hauteur - 150); // Cuisiniers en bas
                    cuisinierPos++;
                }

                positions[sommet] = pos;
            }


            using (Pen pen = new Pen(Color.Black, 2))
            {
                foreach (var arrete in arretes)
                {
                    Point p1 = positions[arrete.Item1];
                    Point p2 = positions[arrete.Item2];
                    g.DrawLine(pen, p1, p2);
                }
            }


            for (int i = 0; i < sommets.Count; i++)
            {
                string sommet = sommets[i];
                Point centre = positions[sommet];
                Color couleur = couleurs[i] < palette.Count ? palette[couleurs[i]] : Color.Black;

                Brush brush = new SolidBrush(couleur);
                Rectangle cercle = new Rectangle(centre.X - rayon, centre.Y - rayon, rayon * 2, rayon * 2);
                g.FillEllipse(brush, cercle);
                g.DrawEllipse(Pens.Black, cercle);


                g.DrawString(sommet, new Font("Arial", 10), Brushes.Black, centre.X - rayon / 2, centre.Y - rayon / 2);
            }
        }

    }
}