﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace map_métro_paris
{
    internal class appli_commande
    {

        public static void appli()
        {
            bool connecté = false;
            while (true)  // boucle infini
            {
                Console.Clear();
                // cuisinier aussi formulaire et connexion avec root mais vous simuler envoie de mail avec mdp ensuite on passe à ici


                string uti = "", pswd = "";
                MySqlConnection maConnection = null;
                bool connec = false;
                int saisi = -1;

                int choix = -1;  // 0 inscription,  1 connexion
                Console.WriteLine("0 pour s'inscrire / 1 pour se connecter");
                choix = Saisieval(0, 1);

                if (choix == 0)  // inscription
                {
                    #region connexion_a_root
                    uti = "root";
                    pswd = "root";
                    string connectionString = $"SERVER=localhost;PORT=3306;DATABASE=projet;UID={uti};PASSWORD={pswd};";
                    maConnection = new MySqlConnection(connectionString);

                    try
                    {
                        maConnection.Open();
                        connec = true;

                    }
                    catch (MySqlException ex)
                    {
                        switch (ex.Number)
                        {
                            case 0:
                                Console.WriteLine("Impossible de se connecter au serveur.");
                                break;
                            case 1045:
                                Console.WriteLine("Mauvais identifiant ou mot de passe.");
                                break;
                            default:
                                Console.WriteLine($"Erreur MySQL : {ex.Message}");
                                break;
                        }
                    }
                    #endregion

                    #region crea_et_verif_ID_uti
                    int ran = new Random().Next(1000000, 9999999);
                    int id_utilisateur = ran;
                    int id_Client = ran;
                    int id_Cuisinier = ran;
                    MySqlCommand command = maConnection.CreateCommand();
                    command.CommandText = $"SELECT count(*) FROM utilisateur WHERE id_utilisateur = {id_utilisateur};";
                    object result = command.ExecuteScalar();

                    while (Convert.ToInt32(result) == 1)
                    {
                        ran = new Random().Next(1000000, 9999999);
                        id_utilisateur = ran;
                        command = maConnection.CreateCommand();
                        command.CommandText = $"SELECT count(*) FROM utilisateur WHERE id_utilisateur = {id_utilisateur};";
                        result = command.ExecuteScalar();
                    }
                    #endregion

                    Console.WriteLine("créé un compte cuisinier (1) ou Client (2) ?");
                    int choixrole = Saisieval(1, 2);
                    if (choixrole == 1)   // Cuisinier
                    {
                        id_Cuisinier = id_utilisateur;
                    }
                    else if (choixrole == 2)  // Client
                    {
                        id_Client = id_utilisateur;
                    }

                    #region insertion_utilisateur_client_cuisinier
                    Console.Clear();
                    Console.WriteLine("entrer votre prenom");
                    string prenom = Console.ReadLine();

                    Console.WriteLine("entrer votre Nom");
                    string nom = Console.ReadLine();

                    Console.WriteLine("entrer votre telephone");
                    int tel = Saisieval(0100000000, 0999999999);

                    Console.WriteLine("entrer votre mail");
                    string mail = Console.ReadLine();  //

                    #region verif_mail

                    MySqlCommand commandma = maConnection.CreateCommand();
                    commandma.CommandText = "SELECT count(*) FROM utilisateur WHERE mail = @mail";
                    commandma.Parameters.AddWithValue("@mail", mail);

                    object resultma = commandma.ExecuteScalar();

                    while (Convert.ToInt32(resultma) == 1)
                    {

                        Console.WriteLine("Entrez un autre email :");
                        mail = Console.ReadLine();

                        commandma = maConnection.CreateCommand();
                        commandma.CommandText = "SELECT count(*) FROM utilisateur WHERE mail = @mail";
                        commandma.Parameters.Clear();
                        commandma.Parameters.AddWithValue("@mail", mail);
                        resultma = commandma.ExecuteScalar();
                    }
                    #endregion



                    Console.WriteLine("entrer votre mot de passe");
                    string mdp = Console.ReadLine();

                    Console.WriteLine("entrer votre adresse postal");
                    string aposte = Console.ReadLine();


                    //insérer utilisateur
                    MySqlCommand commanduti = maConnection.CreateCommand();
                    commanduti.CommandText = @"INSERT INTO utilisateur (id_utilisateur, Prénom, Nom, Téléphone, Mail, Mot_de_passe, Adresse_postale) VALUE
                    (@id_utilisateur,@Prénom,@nom,@Téléphone,@Mail,@Mot_de_passe,@Adresse_posale);";
                    commanduti.Parameters.AddWithValue("@id_utilisateur", id_utilisateur);
                    commanduti.Parameters.AddWithValue("@Prénom", prenom);
                    commanduti.Parameters.AddWithValue("@nom", nom);
                    commanduti.Parameters.AddWithValue("@Téléphone", tel);
                    commanduti.Parameters.AddWithValue("@Mail", mail);
                    commanduti.Parameters.AddWithValue("@Mot_de_passe", mdp);
                    commanduti.Parameters.AddWithValue("@Adresse_posale", aposte);

                    commanduti.ExecuteNonQuery();
                    Console.WriteLine($"compte utilisateur ajouté");

                    // insserer cuisinier

                    if (choixrole == 1)
                    {
                        MySqlCommand commandcui = maConnection.CreateCommand();
                        commandcui.CommandText = @"INSERT INTO Client (Id_Cuisinier,id_utilisateur) VALUE
                    (@Id_Cuisinier,@id_utilisateur);";
                        commandcui.Parameters.AddWithValue("@Id_Client", id_Cuisinier);
                        commandcui.Parameters.AddWithValue("@id_utilisateur", id_utilisateur);



                        commandcui.ExecuteNonQuery();
                        Console.WriteLine($"Cuisinier ajouté");
                    }

                    // insserer Client

                    if (choixrole == 2)
                    {
                        MySqlCommand commandcli = maConnection.CreateCommand();
                        commandcli.CommandText = @"INSERT INTO Client (Id_Client,id_utilisateur) VALUE
                    (@Id_Client,@id_utilisateur);";
                        commandcli.Parameters.AddWithValue("@Id_Client", id_Client);
                        commandcli.Parameters.AddWithValue("@id_utilisateur", id_utilisateur);



                        commandcli.ExecuteNonQuery();
                        Console.WriteLine($"client client ajouté");

                    }
                    #endregion

                }  // 0 inscription

                while (!connec && choix == 1)  // 1 connexion
                {
                    Console.WriteLine("Vous etes cuisinier ou client? 1 cuisinier / 2 client / 3 admin");
                    saisi = Saisieval(0, 3);
                    if (saisi == 1)  // 1 Cuisinier 
                    {
                        Console.WriteLine("Saisir le mot de passe :");
                        uti = "Cuisinier";
                        pswd = Console.ReadLine();

                    }
                    else if (saisi == 2)    // 2 client
                    {
                        uti = "Client";
                        pswd = "12345";


                    }
                    else if (saisi == 3)  // Administrateur
                    {
                        uti = "root";
                        Console.WriteLine("Saisir le mot de passe admin :");
                        pswd = Console.ReadLine();  // root  ou admin

                    }
                    else break;

                    #region connexion
                    string connectionString = $"SERVER=localhost;PORT=3306;DATABASE=projet;UID={uti};PASSWORD={pswd};";
                    maConnection = new MySqlConnection(connectionString);

                    try
                    {
                        maConnection.Open();
                        connec = true;

                    }
                    catch (MySqlException ex)
                    {
                        switch (ex.Number)
                        {
                            case 0:
                                Console.WriteLine("Impossible de se connecter au serveur.");
                                break;
                            case 1045:
                                Console.WriteLine("Mauvais identifiant ou mot de passe.");
                                break;
                            default:
                                Console.WriteLine($"Erreur MySQL : {ex.Message}");
                                break;
                        }
                    }
                    #endregion

                } // 1 conexion (client/cuisinier/root)



                if (saisi == 1)  // cuisinier
                {

                    #region verif_cuisinier
                    bool identifié = false;
                    while (!identifié)
                    {
                        Console.WriteLine("adresse mail:");
                        string mailcuisinier = Console.ReadLine();
                        string mdp_de_mail = $"select mot_de_passe from utilisateur u join cuisinier c on c.id_utilisateur = u.id_utilisateur where u.mail = \'{mailcuisinier}' ;";

                        Console.WriteLine("mot de passe:");
                        string mdpcuisinier = Console.ReadLine();
                        string mdpattendu = Afficher_mdp_de_mail(maConnection, mdp_de_mail);
                        if (mdpcuisinier == mdpattendu)
                        {
                            Console.WriteLine("connextion réussi");
                            Console.ReadLine();
                            identifié = true;
                        }
                        if (mdpcuisinier == "0" || mailcuisinier == "0")
                        {
                            Console.Clear();
                            break;
                        }
                        Console.Clear();

                    }
                    #endregion
                    if (identifié)
                    {
                        Console.Clear();
                        LancerInterfaceCuisinier(maConnection);
                    }
                } // cuisinier

                else if (saisi == 2)  // client
                {
                    #region verif_client

                    bool identifié = false;
                    string mailclient = "0";
                    while (!identifié)
                    {
                        Console.WriteLine("adresse mail:");
                        mailclient = Console.ReadLine();
                        string mdp_de_mail = $"select mot_de_passe from utilisateur u join client c on c.id_utilisateur = u.id_utilisateur where u.mail = \'{mailclient}' ;";

                        Console.WriteLine("mot de passe:");
                        string mdpclient = Console.ReadLine();
                        string mdpattendu = Afficher_mdp_de_mail(maConnection, mdp_de_mail);
                        if (mdpclient == mdpattendu)
                        {
                            Console.WriteLine("connextion réussi");
                            Console.ReadLine();
                            identifié = true;
                        }
                        if (mdpclient == "0" || mailclient == "0")
                        {
                            Console.Clear();
                            break;
                        }
                        Console.Clear();

                    }
                    #endregion
                    if (identifié)
                    {
                        Console.Clear();
                        LancerInterfaceClient(maConnection, mailclient);
                    }
                } // client

                else if (saisi == 3) // admin
                {

                    Console.WriteLine("connexion admin :");
                    LancerInterfaceAdmin(maConnection);

                }  // admin

                if (connec)
                {
                    maConnection.Close();
                }

            }
        }


        static void LancerInterfaceClient(MySqlConnection maConnection, string mailclient)
        {
            Dictionary<string, int> panier = new Dictionary<string, int>();
            string adresseLivraison = "";

            Console.WriteLine("Entrez votre adresse de livraison :");
            adresseLivraison = "au " + Console.ReadLine();

            int idCuisinier = 0;
            int idClient = IDclientdepuismail(maConnection, mailclient);

            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== Interface Client ===");
                Console.WriteLine("Souhaitez-vous ajouter un plat ou valider le panier ? (plat/panier)");
                string choix = Console.ReadLine().ToLower();

                if (choix == "plat")
                {

                    string platChoisi = AfficherPlats(maConnection);
                    Console.Clear();


                    Afficher_Ingrédient(maConnection, platChoisi);
                    Afficher_avis_du_plat_du_cuisinier(maConnection, platChoisi);

                    Console.WriteLine("Combien de parts ?");
                    int nbParts = int.Parse(Console.ReadLine());

                    if (panier.ContainsKey(platChoisi))
                        panier[platChoisi] += nbParts;
                    else
                        panier.Add(platChoisi, nbParts);

                    Console.WriteLine("Plat ajouté !");

                    idCuisinier = IDcuisinierdepuisplat(maConnection, platChoisi);
                }
                else if (choix == "panier")
                {
                    Console.Clear();
                    Console.WriteLine("Contenu du panier :");

                    foreach (var plat in panier)
                    {
                        Console.WriteLine($"{plat.Key} x{plat.Value}");

                        ticketdecaisse(maConnection, idClient, idCuisinier, panier, adresseLivraison);
                    }
                    Console.ReadLine();
                    break;
                }
                else
                {

                    Console.WriteLine("Choix invalide. Veuillez entrer 'plat' ou 'panier'.");
                }
            }
        }

        static void LancerInterfaceCuisinier(MySqlConnection maConnection)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("interface cuisinier");
                Console.WriteLine("1. Ajouter un plat");
                Console.WriteLine("2. Voir le menu");
                Console.WriteLine("3. Ajouter un ingrédient");
                Console.WriteLine("4. Quitter");
                string choix = Console.ReadLine();

                if (choix == "1")
                {
                    Console.WriteLine("Votre Id cuisinier :");
                    string Id_Cuisinier = Console.ReadLine();
                    Ajoutplat(maConnection, Id_Cuisinier);
                }
                else if (choix == "2")
                {
                    Console.Clear();
                    Afficherplat2(maConnection);
                    Console.WriteLine("Souhaitez-vous supprimer un plat ? (oui/non)");
                    string verif = Saisiestring("oui", "non");

                    if (verif == "oui")
                    {
                        nuc(maConnection);
                        Console.WriteLine("Votre plat a été supprimé.");
                    }
                    else
                    {
                        Console.WriteLine("Souhaitez-vous afficher les ingrédients d'un plat ? (oui/non)");
                        string verif2 = Saisiestring("oui", "non");

                        if (verif2 == "oui")
                        {
                            Console.Clear();
                            Afficherplat2(maConnection);
                            Console.WriteLine("Sélectionner un plat :");
                            string platchoisi = Console.ReadLine();
                            Afficher_Ingrédient(maConnection, platchoisi);
                            Console.ReadLine();
                        }
                    }
                }
                else if (choix == "3")
                {
                    Console.Clear();
                    Afficherplat2(maConnection);
                    Console.WriteLine("Pour quel plat souhaitez-vous ajouter un ingrédient ?");
                    string platchoisi = Console.ReadLine();
                    AjoutIngredient(maConnection, platchoisi);

                    Console.WriteLine("Souhaitez-vous afficher la liste des ingrédients ? (oui/non)");
                    string verif = Console.ReadLine();

                    if (verif == "oui")
                    {
                        Afficher_Ingrédient(maConnection, platchoisi);
                    }
                }
                else if (choix == "4")
                {
                    maConnection.Close();
                    return;
                }
            }


            // 🔁 Tu dois définir ou importer les fonctions suivantes :
            // - Saisiestring(string, string)
            // - AfficherPlats(MySqlConnection)
            // - Afficher_Ingrédient(MySqlConnection, string)
            // - Afficher_avis_du_plat_du_cuisinier(MySqlConnection, string)
            // - ticketdecaisse(List<string>)
            // - Ajoutplat, Afficherplat2, nuc, AjoutIngredient...
        }

        static void LancerInterfaceAdmin(MySqlConnection maConnection)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("interface Admin ");
                Console.WriteLine("1. voir stat");
                Console.WriteLine("2. Voir le menu");
                Console.WriteLine("3. Ajouter un ingrédient");// a supp
                Console.WriteLine("4. Quitter");
                string choix = Console.ReadLine();

                if (choix == "1")  // requette
                {
                    Console.Clear();
                    Console.WriteLine("1 pour stat préfaite / 2 pour requette perso");
                    string choixreq = Saisiestring("1", "2");
                    if (choixreq == "1")//préfait
                    {
                        Console.WriteLine("nombre d'utilisateur : ");
                        string s1 = "SELECT count(*) FROM utilisateur;";
                        AfficherResultatsRequete(maConnection, s1);

                        Console.WriteLine("nombre de client : ");
                        string s2 = "SELECT count(*) FROM Client;";
                        AfficherResultatsRequete(maConnection, s2);

                        Console.WriteLine("utilisateur avec mot de passe faible : ");
                        string s3 = "select count(*) from utilisateur where char_length(Mot_de_passe) <5;";
                        AfficherResultatsRequete(maConnection, s3);

                        Console.WriteLine("la plus grosse dépense : ");
                        string s4 = "SELECT u.Prénom, u.Nom, SUM(c.Prix) AS Total_Dépensé\r\nFROM utilisateur u\r\nJOIN Client cl ON u.id_utilisateur = cl.id_utilisateur\r\nJOIN Commande c ON cl.Id_Client = c.Id_Client\r\nGROUP BY u.Prénom, u.Nom\r\nORDER BY Total_Dépensé DESC\r\nLIMIT 1;";
                        AfficherResultatsRequete(maConnection, s4);

                        Console.WriteLine("Le cuisinier ayant reçu la meilleure note moyenne : ");
                        string s5 = "SELECT u.Prénom, u.Nom, AVG(a.Note) AS Moyenne_Note\r\nFROM avis a\r\nJOIN Cuisinier cu ON a.Id_Cuisinier = cu.Id_Cuisinier\r\nJOIN utilisateur u ON cu.id_utilisateur = u.id_utilisateur\r\nGROUP BY u.Prénom, u.Nom\r\nORDER BY Moyenne_Note DESC\r\nLIMIT 1;\r\n";
                        AfficherResultatsRequete(maConnection, s5);

                        Console.WriteLine("Le plat le plus commandé : ");
                        string s6 = "SELECT p.Nom_plat, COUNT(c.Id_Commande) AS Nombre_Commandes\r\nFROM Plat p\r\nJOIN Commande c ON p.Nom_plat = c.nom_plat\r\nGROUP BY p.Nom_plat\r\nORDER BY Nombre_Commandes DESC\r\nLIMIT 1;\r\n";
                        AfficherResultatsRequete(maConnection, s6);

                        Console.WriteLine(" Le client ayant passé le plus de commandes : ");
                        string s7 = "SELECT u.Prénom, u.Nom, COUNT(c.Id_Commande) AS Nombre_Commandes\r\nFROM utilisateur u\r\nJOIN Client cl ON u.id_utilisateur = cl.id_utilisateur\r\nJOIN Commande c ON cl.Id_Client = c.Id_Client\r\nGROUP BY u.Prénom, u.Nom\r\nORDER BY Nombre_Commandes DESC\r\nLIMIT 1;\r\n";
                        AfficherResultatsRequete(maConnection, s7);

                        Console.WriteLine(" Le plat le plus cher : ");
                        string s8 = "SELECT Nom_plat, Prix\r\nFROM Plat\r\nORDER BY Prix DESC\r\nLIMIT 1;\r\n";
                        AfficherResultatsRequete(maConnection, s8);

                        Console.WriteLine("zzzzzzzzzzzzzzzzzzzz : ");
                        string s9 = "SELECT count(*) FROM Cuisinier;";
                        AfficherResultatsRequete(maConnection, s9);

                        Console.WriteLine("zzzzzzzzzzzzzzzzzzzz : ");
                        string s10 = "SELECT count(*) FROM Cuisinier;";
                        AfficherResultatsRequete(maConnection, s10);

                        Console.ReadLine();
                    }
                    else if (choixreq == "2")//perso
                    {
                        Console.WriteLine("entrez votre requette : ");
                        string s0 = Console.ReadLine();
                        AfficherResultatsRequete(maConnection, s0);
                        Console.ReadLine();
                    }


                }

                else if (choix == "2")
                {
                    Console.Clear();
                    Afficherplat2(maConnection);
                    Console.WriteLine("Souhaitez-vous supprimer un plat ? (oui/non)");
                    string verif = Saisiestring("oui", "non");

                    if (verif == "oui")
                    {
                        nuc(maConnection);
                        Console.WriteLine("Votre plat a été supprimé.");
                    }
                    else
                    {
                        Console.WriteLine("Souhaitez-vous afficher les ingrédients d'un plat ? (oui/non)");
                        string verif2 = Saisiestring("oui", "non");

                        if (verif2 == "oui")
                        {
                            Console.Clear();
                            Afficherplat2(maConnection);
                            Console.WriteLine("Sélectionner un plat :");
                            string platchoisi = Console.ReadLine();
                            Afficher_Ingrédient(maConnection, platchoisi);
                            Console.ReadLine();
                        }
                    }
                }
                else if (choix == "3")
                {
                    Console.Clear();
                    Afficherplat2(maConnection);
                    Console.WriteLine("Pour quel plat souhaitez-vous ajouter un ingrédient ?");
                    string platchoisi = Console.ReadLine();
                    AjoutIngredient(maConnection, platchoisi);

                    Console.WriteLine("Souhaitez-vous afficher la liste des ingrédients ? (oui/non)");
                    string verif = Console.ReadLine();

                    if (verif == "oui")
                    {
                        Afficher_Ingrédient(maConnection, platchoisi);
                    }
                }
                else if (choix == "4")
                {
                    maConnection.Close();
                    return;
                }
            }


            // 🔁 Tu dois définir ou importer les fonctions suivantes :
            // - Saisiestring(string, string)
            // - AfficherPlats(MySqlConnection)
            // - Afficher_Ingrédient(MySqlConnection, string)
            // - Afficher_avis_du_plat_du_cuisinier(MySqlConnection, string)
            // - ticketdecaisse(List<string>)
            // - Ajoutplat, Afficherplat2, nuc, AjoutIngredient...
        }


        public static void AfficherResultatsRequete(MySqlConnection maConnection, string requete)
        {
            try
            {
                // Créer la commande SQL
                MySqlCommand command = maConnection.CreateCommand();
                command.CommandText = requete;

                // Exécuter la commande et obtenir un DataReader
                MySqlDataReader reader = command.ExecuteReader();

                // Vérifier si des résultats sont présents
                if (reader.HasRows)
                {
                    // Afficher les noms des colonnes
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        Console.Write(reader.GetName(i) + "\t");
                    }
                    Console.WriteLine();

                    // Afficher les valeurs des colonnes pour chaque ligne
                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            Console.Write(reader.GetValue(i) + "\t");
                        }
                        Console.WriteLine();
                    }
                }
                else
                {
                    Console.WriteLine("Aucun résultat trouvé.");
                }

                reader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur lors de l'exécution de la requête : " + ex.Message);
            }
        }

        public static string Afficher_mdp_de_mail(MySqlConnection maConnection, string requete)
        {
            string resultat = null;

            try
            {
                // Créer la commande SQL
                MySqlCommand command = maConnection.CreateCommand();
                command.CommandText = requete;

                // Exécuter la commande et obtenir un DataReader
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    // Vérifier si des résultats sont présents
                    if (reader.HasRows)
                    {
                        // Lire la première ligne (dans le cas où il n'y a qu'un seul résultat)
                        if (reader.Read())
                        {
                            // Récupérer la première valeur de la ligne (index 0)
                            resultat = reader.GetValue(0).ToString();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Aucun résultat trouvé.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur lors de l'exécution de la requête : " + ex.Message);
            }

            return resultat;
        }


        static string AfficherPlats(MySqlConnection maConnection)
        {
            string platchoisi = "";
            try
            {
                MySqlCommand command = maConnection.CreateCommand();
                command.CommandText = "SELECT \r\n    Nom_plat, \r\n    Prix, \r\n    Nationalité, \r\n    Nom AS Nom_Cuisinier, \r\n    (SELECT AVG(Note) \r\n     FROM avis \r\n     WHERE avis.Id_Cuisinier = Cuisinier.Id_Cuisinier) AS Note_Cuisinier\r\nFROM Cuisinier\r\nJOIN utilisateur ON Cuisinier.id_utilisateur = utilisateur.id_utilisateur\r\nJOIN Plat ON Plat.Id_Cuisinier = Cuisinier.Id_Cuisinier;";

                using MySqlDataReader reader = command.ExecuteReader();
                Console.WriteLine("\nListe des plats :");

                string[] valuestring = new string[reader.FieldCount];
                List<string> platsDisponibles = new List<string>();// pour liste verif
                while (reader.Read())
                {

                    valuestring[0] = reader.GetValue(0).ToString();
                    platsDisponibles.Add(valuestring[0]); // pour liste verif
                    Console.WriteLine(valuestring[0] + ":");
                    for (int i = 1; i < reader.FieldCount; i++)
                    {
                        string s0 = "";
                        string s1 = "";
                        if (i == 1) { s0 = " euros"; }
                        if (i == 2) { s1 = "nationalité "; }
                        if (i == 3) { s1 = "cuisinier : "; }
                        if (i == 4) { s1 = "note : "; }

                        valuestring[i] = reader.GetValue(i).ToString();
                        Console.Write(s1 + valuestring[i] + s0 + "\t\t");

                    }
                    Console.WriteLine();
                    Console.WriteLine();
                }
                Console.WriteLine("Choisissez un plat"); // mtn il faut : l'avi en entier / les ingrédient / si on veut le commander

                // Saisie sécurisée
                Console.WriteLine("Choisissez un plat parmi la liste :");


                bool platValide = false;

                while (!platValide)
                {
                    Console.Write("Nom du plat : ");
                    platchoisi = Console.ReadLine();

                    if (platsDisponibles.Contains(platchoisi))
                    {
                        platValide = true;
                    }
                    else
                    {
                        Console.WriteLine("Plat invalide. Veuillez réessayer.");
                    }
                }

                // saisi sécu fin

                return platchoisi;



            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur : " + ex.Message);
                return platchoisi;
            }
        }

        static void Afficher_Ingrédient(MySqlConnection maConnection, string platchoisi)
        {
            try
            {
                MySqlCommand command = maConnection.CreateCommand();
                command.CommandText = $"SELECT \r\n    i.Nom AS Nom_ingredient,\r\n    i.Origine,\r\n    i.Régime_alimentaire,\r\n    i.certification\r\nFROM \r\n    Plat_Ingredient pi\r\nJOIN \r\n    Ingrédient i ON pi.Nom_ingredient = i.Nom\r\nWHERE \r\n    pi.Nom_plat = '{platchoisi}';";

                using MySqlDataReader reader = command.ExecuteReader();
                Console.WriteLine("\ninggrédient du plat :");

                string[] valuestring = new string[reader.FieldCount];
                while (reader.Read())
                {
                    valuestring[0] = reader.GetValue(0).ToString();
                    Console.WriteLine(valuestring[0] + ":");
                    for (int i = 1; i < reader.FieldCount; i++)
                    {
                        valuestring[i] = reader.GetValue(i).ToString();
                        Console.Write(valuestring[i] + "\t\t");
                    }
                    Console.WriteLine();
                    Console.WriteLine();
                }





            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur : " + ex.Message);
            }
        }

        static void Afficher_avis_du_plat_du_cuisinier(MySqlConnection maConnection, string platchoisi)
        {
            try
            {
                MySqlCommand command = maConnection.CreateCommand();
                command.CommandText = $"SELECT u.Prénom,u.Nom,a.Note,a.Titre,a.Commentaire FROM Plat p JOIN    Cuisinier c ON p.Id_Cuisinier = c.Id_Cuisinier\r\nJOIN \r\n    avis a ON a.Id_Cuisinier = c.Id_Cuisinier\r\nJOIN \r\n    Client cl ON a.Id_Client = cl.Id_Client\r\nJOIN \r\n    utilisateur u ON cl.id_utilisateur = u.id_utilisateur\r\nWHERE \r\n    p.Nom_plat = '{platchoisi}';";

                using MySqlDataReader reader = command.ExecuteReader();
                Console.WriteLine("\nAvis du Cuisinier:");

                string[] valuestring = new string[reader.FieldCount];
                while (reader.Read())
                {
                    valuestring[0] = reader.GetValue(0).ToString();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        string s0 = "";
                        string s1 = "";
                        if (i == 0) { s0 = " "; }
                        if (i == 1) { s0 = " "; }
                        if (i == 2) { s0 = "/5"; }
                        if (i == 3) { s1 = "\n"; }
                        if (i == 4) { s1 = ", "; }


                        valuestring[i] = reader.GetValue(i).ToString();
                        Console.Write(s1 + valuestring[i] + s0);

                    }
                    Console.WriteLine();
                    Console.WriteLine();
                }





            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur : " + ex.Message);
            }
        }





        /// <summary>
        /// créé un reçu pour le client et utilisable par le cuisinier pour la livraision
        /// </summary>
        /// <param name="contenuListe"></param>
        static void ticketdecaisse(MySqlConnection maConnection, int idClient, int idCuisinier, Dictionary<string, int> platsAvecParts, string adresse_liv)
        {
            int prixTotal = 0;
            Random ran = new Random();

            // Vérifier si l'idClient existe dans la table Client
            var verifClient = new MySqlCommand("SELECT COUNT(*) FROM Client WHERE Id_Client = @idClient", maConnection);
            verifClient.Parameters.AddWithValue("@idClient", idClient);
            int clientCount = Convert.ToInt32(verifClient.ExecuteScalar());

            if (clientCount == 0)
            {
                Console.WriteLine($"Erreur : Le client avec id {idClient} n'existe pas.");
                return;  // Arrêter l'exécution si le client n'existe pas
            }

            // Calculer le prix total
            foreach (var entry in platsAvecParts)
            {
                string nomPlat = entry.Key;
                int nbPart = entry.Value;

                MySqlCommand commande = new MySqlCommand("SELECT Prix FROM Plat WHERE Nom_plat = @nom AND Id_Cuisinier = @idCuisinier", maConnection);
                commande.Parameters.AddWithValue("@nom", nomPlat);
                commande.Parameters.AddWithValue("@idCuisinier", idCuisinier);

                object result = commande.ExecuteScalar();
                if (result == null)
                {
                    Console.WriteLine($"Erreur : plat '{nomPlat}' invalide ou pas du cuisinier {idCuisinier}");
                    return;
                }

                int prix = Convert.ToInt32(result);
                prixTotal += prix * nbPart;
            }

            int idCommande = 0;
            bool idUnique = false;

            // Générer un id unique pour la commande
            while (!idUnique)
            {
                idCommande = ran.Next(1000000, 9999999);
                var verifcmd = new MySqlCommand("SELECT COUNT(*) FROM Commande WHERE Id_Commande = @id", maConnection);
                verifcmd.Parameters.AddWithValue("@id", idCommande);
                int count = Convert.ToInt32(verifcmd.ExecuteScalar());

                if (count == 0)
                    idUnique = true;
            }

            var date_ajd = DateTime.Now;
            foreach (var entry in platsAvecParts) // modifier cela pour que cela marche pour plusieur plat !!!!!!
            {
                string nomPlat = entry.Key;


                // Insertion de la commande dans la base de données
                var insertCommande = new MySqlCommand(@"
INSERT INTO Commande (Id_Commande, Date_commande,Nom_plat, Prix, Temps, Statut, Id_Cuisinier, Id_Client)
VALUES (@id, @date,@nom, @prix, @temps, 'En cours', @cuisinier, @client)", maConnection);
                insertCommande.Parameters.AddWithValue("@id", idCommande);
                insertCommande.Parameters.AddWithValue("@date", date_ajd);
                insertCommande.Parameters.AddWithValue("@nom", nomPlat);
                insertCommande.Parameters.AddWithValue("@prix", prixTotal);
                insertCommande.Parameters.AddWithValue("@temps", date_ajd.AddMinutes(30));
                insertCommande.Parameters.AddWithValue("@cuisinier", idCuisinier);
                insertCommande.Parameters.AddWithValue("@client", idClient);
                insertCommande.ExecuteNonQuery();
            }

            // Insertion des plats dans la table exemp_plat
            foreach (var entry in platsAvecParts)
            {
                string nomPlat = entry.Key;
                int nbPart = entry.Value;

                for (int i = 0; i < nbPart; i++)
                {
                    var insertPlat = new MySqlCommand("INSERT INTO exemp_plat (id, adresse_liv, Nom_plat, Id_Commande) VALUES (@id, @adr, @nom, @cmd)", maConnection);
                    insertPlat.Parameters.AddWithValue("@id", ran.Next(1000000, 9999999));
                    insertPlat.Parameters.AddWithValue("@adr", adresse_liv);
                    insertPlat.Parameters.AddWithValue("@nom", nomPlat);
                    insertPlat.Parameters.AddWithValue("@cmd", idCommande);
                    insertPlat.ExecuteNonQuery();
                }
            }

            Console.Clear();
            Console.WriteLine("\n=== TICKET DE CAISSE ===");
            Console.WriteLine($"Commande ID: {idCommande}");
            Console.WriteLine($"Client ID: {idClient}");
            Console.WriteLine($"Cuisinier ID: {idCuisinier}");
            Console.WriteLine($"Adresse de livraison: {adresse_liv}");
            Console.WriteLine($"Date de commande: {date_ajd}");
            Console.WriteLine("Plats commandés :");

            foreach (var entry in platsAvecParts)
            {
                string nomPlat = entry.Key;
                int nbPart = entry.Value;
                Console.WriteLine($"- {nomPlat} (x{nbPart})");
            }

            Console.WriteLine($"Prix total: {prixTotal}€");
            Console.WriteLine("===========================");
        }

        /// <summary>
        /// saisi sécurisé entre 2 string
        /// </summary>
        static string Saisiestring(string x, string y)
        {
            string val = "";
            while (true)
            {
                string st = Console.ReadLine();   // string a tester

                if (st == x || st == y) // si c'est dans l'interval 
                {
                    val = st;
                    break;
                }
                else
                {
                    Console.WriteLine($"il faut que ce sois {x} ou {y} ");
                }
            }
            return val;
        }

        /// <summary>
        /// permet d'autoriser des nombre entier dans un interval
        /// </summary>
        static int Saisieval(int x, int y)
        {
            int val;
            while (true)
            {
                string st = Console.ReadLine();

                try
                {
                    val = Convert.ToInt32(st);
                    if (val >= x && val <= y) // si c'est dans l'interval 
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine($"Nombre entre {x} et {y}");
                    }
                }
                catch
                {
                    Console.WriteLine($"numéro entre {x} et {y}");
                }
            }
            return val;
        }


        /// <summary>
        /// Permet au cuisinier d'ajouter un plat
        /// </summary>
        /// <param name="maConnection"></param>
        /// <param name="Id_Cuisinier"></param>
        static void Ajoutplat(MySqlConnection maConnection, string Id_Cuisinier)
        {
            Console.WriteLine("Nom du plat :");
            string nouvplat = Console.ReadLine();

            Console.WriteLine("Prix du plat :");
            string prix = Console.ReadLine(); //faire une saisie sec

            Console.WriteLine("Nationalité du plat :");
            string Nat = Console.ReadLine();

            MySqlCommand command = maConnection.CreateCommand();
            command.CommandText = @"INSERT INTO Plat (Nom_plat, Prix, Nationalité, Id_Cuisinier) VALUE (@Nom_plat,@Prix,@Nationalité,@Id_Cuisinier);";
            command.Parameters.AddWithValue("@Nom_plat", nouvplat);
            command.Parameters.AddWithValue("@Prix", prix);
            command.Parameters.AddWithValue("@Nationalité", Nat);
            command.Parameters.AddWithValue("@Id_Cuisinier", Id_Cuisinier);

            command.ExecuteNonQuery();
            Console.WriteLine($"Le plat : {nouvplat} a été ajouté");
        }

        /// <summary>
        /// permet de suprimer un plat
        /// </summary>
        /// <param name="maConnection"></param>
        static void nuc(MySqlConnection maConnection)
        {
            Console.WriteLine("Quelle plat souhaitez vous supprimer");
            string platsupp = Console.ReadLine();
            MySqlCommand command = maConnection.CreateCommand();
            command.CommandText = @"DELETE FROM Plat_Ingredient WHERE Nom_plat = @Nom";
            command.Parameters.AddWithValue("@Nom", platsupp);
            command.ExecuteNonQuery();


            MySqlCommand deletecommand = maConnection.CreateCommand();
            deletecommand.CommandText = @"DELETE FROM Plat WHERE Nom_plat = @Nom";
            deletecommand.Parameters.AddWithValue("@Nom", platsupp);
            deletecommand.ExecuteNonQuery();

        }

        static void AjoutIngredient(MySqlConnection maConnection, string platchoisi)
        {
            while (true)
            {
                Console.WriteLine("Nom de l'ingredient à ajouter :\nou 'Quitter' pout terminer");

                string nomIngr = Console.ReadLine();
                if (nomIngr == "Quitter")
                {
                    break;
                }
                Console.WriteLine("Origine de l'ingredient :");
                string origine = Console.ReadLine();
                Console.WriteLine("Régime alimentaire (halal, vegan, ect) :");
                string regimeali = Console.ReadLine();
                Console.WriteLine("La certification (AOP, bio, ect) :");
                string certif = Console.ReadLine();

                MySqlCommand checkCommand = maConnection.CreateCommand();
                checkCommand.CommandText = "SELECT COUNT(*) FROM `Ingrédient` WHERE Nom = @Nom";
                checkCommand.Parameters.AddWithValue("@Nom", nomIngr);

                int count = Convert.ToInt32(checkCommand.ExecuteScalar());

                if (count == 0)
                {

                    MySqlCommand command = maConnection.CreateCommand();
                    command.CommandText = @"INSERT INTO Ingrédient  (Nom, Origine, Régime_alimentaire, Certification) VALUE (@Nom,@Origine,@Régime_alimentaire,@Certification);";
                    command.Parameters.AddWithValue("@Nom", nomIngr);
                    command.Parameters.AddWithValue("@Origine", origine);
                    command.Parameters.AddWithValue("@Régime_alimentaire", regimeali);
                    command.Parameters.AddWithValue("@Certification", certif);

                    command.ExecuteNonQuery();
                }
                MySqlCommand linkcommand = maConnection.CreateCommand();
                linkcommand.CommandText = @"INSERT INTO Plat_Ingredient (Nom_plat, Nom_ingredient) VALUE (@Nom_plat,@Nom_ingredient);";
                linkcommand.Parameters.AddWithValue("@Nom_plat", platchoisi);
                linkcommand.Parameters.AddWithValue("@Nom_ingredient", nomIngr);
                linkcommand.ExecuteNonQuery();

                Console.WriteLine($"l'ingredient {nomIngr} a été ajoute au plat {platchoisi}");
            }
        }

        static void AjoutCuisinier(MySqlConnection maConnection)
        {
            Console.WriteLine("Nom du cuisinier :");
            string nom = Console.ReadLine();

            Console.WriteLine("Prénom du cuisinier :");
            string prenom = Console.ReadLine();

            Console.WriteLine("Identifiant de connexion souhaité :");
            string identifiant = Console.ReadLine();

            Console.WriteLine("Mot de passe :");
            string motDePasse = Console.ReadLine();

            try
            {
                // 1. Ajouter dans la table utilisateur
                MySqlCommand insertUtilisateur = maConnection.CreateCommand();
                insertUtilisateur.CommandText = @"
            INSERT INTO utilisateur (Nom, Prénom, identifiant, mot_de_passe)
            VALUES (@Nom, @Prenom, @Identifiant, @MotDePasse);
            SELECT LAST_INSERT_ID();";

                insertUtilisateur.Parameters.AddWithValue("@Nom", nom);
                insertUtilisateur.Parameters.AddWithValue("@Prenom", prenom);
                insertUtilisateur.Parameters.AddWithValue("@Identifiant", identifiant);
                insertUtilisateur.Parameters.AddWithValue("@MotDePasse", motDePasse);

                // Récupérer l'ID auto-généré du nouvel utilisateur
                int idUtilisateur = Convert.ToInt32(insertUtilisateur.ExecuteScalar());

                // 2. Ajouter dans la table Cuisinier
                MySqlCommand insertCuisinier = maConnection.CreateCommand();
                insertCuisinier.CommandText = @"
            INSERT INTO Cuisinier (id_utilisateur)
            VALUES (@IdUtilisateur);";
                insertCuisinier.Parameters.AddWithValue("@IdUtilisateur", idUtilisateur);

                insertCuisinier.ExecuteNonQuery();

                Console.WriteLine("Le cuisinier a été ajouté avec succès !");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur lors de l'ajout du cuisinier : " + ex.Message);
            }
        }

        /// <summary>
        /// affiche les plat du point de vu du cuisinier
        /// </summary>
        /// <param name="maConnection"></param>
        static void Afficherplat2(MySqlConnection maConnection)
        {
            MySqlCommand command = maConnection.CreateCommand();
            command.CommandText = "SELECT \r\n    Nom_plat, \r\n    Prix, \r\n    Nationalité, \r\n    Nom AS Nom_Cuisinier, \r\n    (SELECT AVG(Note) \r\n     FROM avis \r\n     WHERE avis.Id_Cuisinier = Cuisinier.Id_Cuisinier) AS Note_Cuisinier\r\nFROM Cuisinier\r\nJOIN utilisateur ON Cuisinier.id_utilisateur = utilisateur.id_utilisateur\r\nJOIN Plat ON Plat.Id_Cuisinier = Cuisinier.Id_Cuisinier;";

            using MySqlDataReader reader = command.ExecuteReader();
            Console.WriteLine("\nListe des plats :");

            string[] valuestring = new string[reader.FieldCount];
            List<string> platsDisponibles = new List<string>();// pour liste verif
            while (reader.Read())
            {

                valuestring[0] = reader.GetValue(0).ToString();
                platsDisponibles.Add(valuestring[0]); // pour liste verif
                Console.WriteLine(valuestring[0] + ":");
                for (int i = 1; i < reader.FieldCount; i++)
                {
                    string s0 = "";
                    string s1 = "";
                    if (i == 1) { s0 = " euros"; }
                    if (i == 2) { s1 = "nationalité "; }
                    if (i == 3) { s1 = "cuisinier : "; }
                    if (i == 4) { s1 = "note : "; }

                    valuestring[i] = reader.GetValue(i).ToString();
                    Console.Write(s1 + valuestring[i] + s0 + "\t\t");

                }
                Console.WriteLine();
                Console.WriteLine();
            }
        }

        static int IDclientdepuismail(MySqlConnection maConnection, string mail)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT id_utilisateur FROM utilisateur WHERE Mail = @Mail", maConnection);
            cmd.Parameters.AddWithValue("@Mail", mail);

            object result = cmd.ExecuteScalar();
            if (result != null)
            {
                int id = Convert.ToInt32(result);
                Console.WriteLine($"Utilisateur trouvé : ID = {id}");
                return id;

            }
            else
            {
                Console.WriteLine("Erreur : client introuvable avec ce mail.");
                return -1;
            }
        }
        static int IDcuisinierdepuisplat(MySqlConnection maConnection, string platChoisi)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT Id_Cuisinier FROM Plat WHERE Nom_plat = @Nom_plat", maConnection);
            cmd.Parameters.AddWithValue("@Nom_plat", platChoisi);

            object result = cmd.ExecuteScalar();
            if (result != null)
            {
                return Convert.ToInt32(result);
            }
            else
            {
                Console.WriteLine("Erreur : Cuisinier introuvable avec ce nom.");
                return -1;
            }
        }









    }
}
